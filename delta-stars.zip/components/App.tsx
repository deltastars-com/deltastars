import React, { useState, useEffect, useMemo, useCallback } from 'react';
// import { motion, AnimatePresence } from 'framer-motion';
import { Header } from './lib/Header';
import { Footer } from './lib/Footer';
import { COMPANY_INFO, SOCIAL_LINKS } from './constants';
import { TelegramIcon, WhatsappIcon } from './lib/contexts/Icons';
import { Product, User, Page, CategoryConfig, CartItem, Promotion, ShowroomItem, CategoryKey, VipClient, HomeSection, Review, ProductUnit, Order, Branch } from '../types';
import { I18nProvider, GeminiAiProvider, useI18n } from './lib/contexts/I18nContext';
import { ToastProvider, useToast } from './ToastContext';
import { ToastContainer } from './ToastContainer';
import { AiAssistant } from './AiAssistant';
import { FirebaseProvider, useFirebase } from './lib/contexts/FirebaseContext';
import { auth, googleProvider, signInWithPopup, signOut } from '../firebase';
import { mockProducts } from './lib/vip/products';
import { mockInvoices, mockVipClients, mockTransactions, mockPayments } from './lib/contexts/accounting';
import { ErrorBoundary } from './ErrorBoundary';
import { SplashScreen } from './lib/SplashScreen';

import { ContactPage } from './ContactPage';
import Home from './Home';
import ProductsPage from './lib/contexts/ProductsPage';
import CartPage from './lib/contexts/CartPage';
import { UnitsPage } from './UnitsPage';
import { LoginPage } from './lib/vip/LoginPage';
import { DashboardPage } from './lib/contexts/DashboardPage';
import { WishlistPage } from './WishlistPage';
import { VipLoginPage } from './VipLoginPage';
import { VipDashboardPage } from './VipDashboardPage';
import { OrderTrackingPage } from './lib/OrderTrackingPage';
import { SourcingRequestPage } from './lib/SourcingRequestPage';
import { LegalPages } from './LegalPages';
import { DeveloperDashboard } from './DeveloperDashboard';
import { DriverDashboardPage } from './lib/DriverDashboardPage';
import { PwaInstallPrompt } from './lib/PwaInstallPrompt';
import { ProductDetailPage } from './lib/ProductDetailPage';
import AdminDashboard from './AdminDashboard';
import { PRODUCT_UNITS } from './constants';

const DEFAULT_CATEGORIES: CategoryConfig[] = [
    { key: 'dates', label_ar: 'تمور', label_en: 'Dates', icon: '🌴', order: 1, isVisible: true },
    { key: 'vegetables', label_ar: 'خضروات', label_en: 'Vegetables', icon: '🥦', order: 2, isVisible: true },
    { key: 'fruits', label_ar: 'فواكة', label_en: 'Fruits', icon: '🍎', order: 3, isVisible: true },
    { key: 'herbs', label_ar: 'ورقيات', label_en: 'Herbs & Greens', icon: '🌿', order: 4, isVisible: true },
    { key: 'qassim', label_ar: 'منتجات القصيم', label_en: 'Qassim Products', icon: '🏜️', order: 5, isVisible: true },
    { key: 'seasonal', label_ar: 'منتجات موسمية', label_en: 'Seasonal Products', icon: '🍂', order: 6, isVisible: true },
    { key: 'packages', label_ar: 'مغلفات', label_en: 'Packages', icon: '📦', order: 7, isVisible: true },
    { key: 'nuts', label_ar: 'مكسرات', label_en: 'Nuts', icon: '🥜', order: 8, isVisible: true },
    { key: 'flowers', label_ar: 'الورود والهدايا', label_en: 'Flowers & Gifts', icon: '🌸', order: 9, isVisible: true },
];

function MainApp() {
  const { language } = useI18n();
  const { addToast } = useToast();
  const { 
    user: firebaseUserData, 
    products: fbProducts, 
    categories: fbCategories, 
    units: fbUnits, 
    homeSections: fbSections, 
    orders: fbOrders, 
    branches: fbBranches,
    loading: fbLoading 
  } = useFirebase();
  const [isInitializing, setIsInitializing] = useState(true);
  const [showAi, setShowAi] = useState(false);
  const [selectedFilterCategory, setSelectedFilterCategory] = useState<CategoryKey | 'all'>( 'all');

  const STORAGE_KEYS = {
      PAGE: 'delta-active-page-v25',
      SESSION: 'delta-active-session-v25',
      PRODUCTS: 'delta-products-data-v25',
      VIP: 'delta-vip-data-v25',
      CART: 'delta-cart-data-v25',
      PROMOS: 'delta-promotions-v25',
      SHOWROOM: 'delta-showroom-data-v25',
      HOME_SECTIONS: 'delta-home-sections-v1',
      UNITS: 'delta-units-v1'
  };

  const safeStorage = {
    save: (key: string, value: any) => {
        try { 
            localStorage.setItem(key, JSON.stringify(value)); 
        } catch (e) { 
            console.warn('Delta Sovereign Storage: Quota exceeded, performing emergency cleanup.');
            // Emergency cleanup of old versions
            Object.keys(localStorage).forEach(k => {
                if (k.includes('delta-') && !k.includes('v25')) localStorage.removeItem(k);
            });
        }
    },
    get: (key: string, fallback: any) => {
        try { 
            const item = localStorage.getItem(key);
            if (!item) return fallback;
            const parsed = JSON.parse(item);
            // Basic data integrity check
            if (typeof parsed !== typeof fallback && fallback !== null) return fallback;
            return parsed;
        } catch { 
            console.error('Delta Sovereign Storage: Data corruption detected for key:', key);
            return fallback; 
        }
    }
  };

  const [currentPage, setCurrentPage] = useState<Page>(() => safeStorage.get(STORAGE_KEYS.PAGE, 'home'));
  const [selectedProductId, setSelectedProductId] = useState<number | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(() => safeStorage.get(STORAGE_KEYS.SESSION, null));
  const [products, setProducts] = useState<Product[]>(() => safeStorage.get(STORAGE_KEYS.PRODUCTS, mockProducts));
  const [systemStatus, setSystemStatus] = useState<'healthy' | 'syncing' | 'optimizing'>('healthy');
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  // Sync with Firebase data when available
  useEffect(() => {
    if (fbProducts.length > 0) setProducts(fbProducts);
  }, [fbProducts]);

  useEffect(() => {
    if (firebaseUserData) setCurrentUser(firebaseUserData);
  }, [firebaseUserData]);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Sovereign Stability Engine: Real-time Performance & Integrity Monitoring
  useEffect(() => {
    const isProduction = window.location.hostname === 'deltastars.com';
    if (isProduction) {
        console.log('%c Delta Sovereign Hub: Production Mode Active (deltastars.com) ', 'background: #1a3a1a; color: #fff; font-weight: bold;');
    }

    const interval = setInterval(() => {
        setSystemStatus('syncing');
        
        // Sovereign Self-Healing & Optimization Routine
        const runMaintenance = () => {
            // 1. Data Integrity Check
            const cartData = safeStorage.get(STORAGE_KEYS.CART, []);
            if (!Array.isArray(cartData)) {
                console.warn('Stability Engine: Cart corruption detected. Auto-repairing...');
                setCart([]);
            }
            
            // 2. Memory Optimization
            if (window.performance && (window.performance as any).memory) {
                const memory = (window.performance as any).memory;
                if (memory.usedJSHeapSize > memory.jsHeapSizeLimit * 0.8) {
                    console.warn('Stability Engine: High memory usage. Triggering optimization...');
                    // Clear non-essential caches if any
                }
            }

            // 3. Session Validation
            const session = safeStorage.get(STORAGE_KEYS.SESSION, null);
            if (session && (!session.type || (!session.email && !session.phone))) {
                console.warn('Stability Engine: Invalid session detected. Securing system...');
                setCurrentUser(null);
            }
            
            setSystemStatus('optimizing');
            setTimeout(() => {
                setSystemStatus('healthy');
                console.log('Delta Sovereign Engine v62.0: System synchronized, memory optimized, and security protocols verified.');
            }, 1000);
        };

        runMaintenance();
    }, 30000); // Increased frequency to 30s for better stability

    // Global Error Capture for Auto-Fix
    const handleError = (event: ErrorEvent) => {
        console.error('Sovereign Hub Auto-Fix: Intercepted fatal error:', event.message);
        // Logic to reset problematic state if needed
        if (event.message.includes('localStorage')) {
            localStorage.clear();
            window.location.reload();
        }
    };

    window.addEventListener('error', handleError);
    return () => {
        clearInterval(interval);
        window.removeEventListener('error', handleError);
    };
  }, [language, addToast]);

  const [promotions, setPromotions] = useState<Promotion[]>(() => safeStorage.get(STORAGE_KEYS.PROMOS, []));
  const [showroomItems, setShowroomItems] = useState<ShowroomItem[]>(() => safeStorage.get(STORAGE_KEYS.SHOWROOM, []));
  const [wishlist, setWishlist] = useState<Product[]>(() => safeStorage.get('delta-wishlist-v25', []));
  const [cart, setCart] = useState<CartItem[]>(() => safeStorage.get(STORAGE_KEYS.CART, []));
  const [vipClients, setVipClients] = useState<VipClient[]>(() => safeStorage.get(STORAGE_KEYS.VIP, mockVipClients));
  const [homeSections, setHomeSections] = useState<HomeSection[]>([
    { id: 'hero', type: 'hero', title_ar: 'البانر الرئيسي', title_en: 'Hero Banner', isVisible: true, order: 1 },
    { id: 'featured_products', type: 'featured_products', title_ar: 'منتجات مختارة', title_en: 'Featured Products', isVisible: true, order: 2 },
    { id: 'categories', type: 'categories', title_ar: 'الأقسام المتخصصة', title_en: 'Specialized Departments', isVisible: true, order: 3 },
    { id: 'partners', type: 'partners', title_ar: 'شركاء النجاح', title_en: 'Strategic Partners', isVisible: true, order: 4 },
    { id: 'customers', type: 'customers', title_ar: 'عملاؤنا الكرام', title_en: 'Our Valued Customers', isVisible: true, order: 5 },
    { id: 'channels', type: 'channels', title_ar: 'قنوات التواصل', title_en: 'Sovereign Channels', isVisible: true, order: 6 }
  ]);

  const [reviews, setReviews] = useState<Review[]>(() => safeStorage.get('delta-reviews-v25', []));
  const [categories, setCategories] = useState<CategoryConfig[]>(() => safeStorage.get('delta-categories-v25', DEFAULT_CATEGORIES));
  const [units, setUnits] = useState<ProductUnit[]>(() => safeStorage.get(STORAGE_KEYS.UNITS, PRODUCT_UNITS));
  const [branches, setBranches] = useState<Branch[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    if (fbCategories.length > 0) setCategories(fbCategories);
  }, [fbCategories]);

  useEffect(() => {
    if (fbUnits.length > 0) setUnits(fbUnits);
  }, [fbUnits]);

  useEffect(() => {
    if (fbSections.length > 0) setHomeSections(fbSections);
  }, [fbSections]);

  useEffect(() => {
    if (fbBranches.length > 0) setBranches(fbBranches);
  }, [fbBranches]);

  useEffect(() => {
    if (fbOrders.length > 0) setOrders(fbOrders);
  }, [fbOrders]);

  useEffect(() => {
    safeStorage.save(STORAGE_KEYS.PRODUCTS, products);
    safeStorage.save(STORAGE_KEYS.PAGE, currentPage);
    safeStorage.save(STORAGE_KEYS.PROMOS, promotions);
    safeStorage.save(STORAGE_KEYS.SHOWROOM, showroomItems);
    safeStorage.save(STORAGE_KEYS.VIP, vipClients);
    safeStorage.save(STORAGE_KEYS.CART, cart);
    safeStorage.save('delta-categories-v25', categories);
    safeStorage.save(STORAGE_KEYS.UNITS, units);
    if (currentUser) safeStorage.save(STORAGE_KEYS.SESSION, currentUser);
    else localStorage.removeItem(STORAGE_KEYS.SESSION);
    safeStorage.save('delta-wishlist-v25', wishlist);
    safeStorage.save('delta-reviews-v25', reviews);
  }, [currentPage, currentUser, vipClients, promotions, showroomItems, cart, wishlist, reviews, products, categories, units]);

  const addReview = useCallback((review: any) => {
    const newReview = { ...review, id: Math.random().toString(36).substr(2, 9) };
    setReviews(prev => [newReview, ...prev]);
  }, []);

  const getProductReviews = useCallback((productId: number) => {
    return reviews.filter(r => r.productId === productId);
  }, [reviews]);

  const getAverageRating = useCallback((productId: number) => {
    const productReviews = reviews.filter(r => r.productId === productId);
    if (productReviews.length === 0) return { average: 5, count: 0 };
    const sum = productReviews.reduce((acc, r) => acc + r.rating, 0);
    return { average: sum / productReviews.length, count: productReviews.length };
  }, [reviews]);

  const toggleWishlist = useCallback((product: Product) => {
    setWishlist(prev => {
      const exists = prev.find(p => p.id === product.id);
      if (exists) {
        addToast(language === 'ar' ? `تمت إزالة ${product.name_ar} من المفضلة` : `Removed ${product.name_en} from wishlist`, 'info');
        return prev.filter(p => p.id !== product.id);
      }
      addToast(language === 'ar' ? `تمت إضافة ${product.name_ar} للمفضلة` : `Added ${product.name_en} to wishlist`, 'success');
      return [...prev, product];
    });
  }, [language, addToast]);

  const isProductInWishlist = useCallback((productId: number) => {
    return wishlist.some(p => p.id === productId);
  }, [wishlist]);

  const addToCart = useCallback((product: Product, quantity: number = 1) => {
    setCart(prev => {
        const existing = prev.find(i => i.id === product.id);
        if (existing) return prev.map(i => i.id === product.id ? { ...i, quantity: i.quantity + quantity } : i);
        return [...prev, { ...product, quantity }];
    });
    addToast(language === 'ar' ? `تمت إضافة ${product.name_ar} للسلة` : `Added ${product.name_en} to cart`, 'success');
  }, [language, addToast]);

  const setPage = useCallback((page: Page, productId?: number, category?: string) => {
    if (category) setSelectedFilterCategory(category as CategoryKey);
    else if (page !== 'products') setSelectedFilterCategory('all');
    if (productId) setSelectedProductId(productId);
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleCheckoutComplete = useCallback((orderData: any) => {
    // Add to purchase history
    console.log('Order finalized:', orderData);
    addToast(language === 'ar' ? 'تم تأكيد طلبك بنجاح! شكراً لتسوقك معنا.' : 'Order confirmed successfully! Thank you for shopping with us.', 'success');
    setCart([]);
    setPage('home');
  }, [language, addToast, setPage]);

  const renderPageContent = () => {
    try {
      const pageProps = {
        initial: { opacity: 0, y: 20 },
        animate: { opacity: 1, y: 0 },
        exit: { opacity: 0, y: -20 },
        transition: { duration: 0.3 }
      };

      switch (currentPage) {
        case 'home': 
            return (
              <div key="home">
                <Home setPage={setPage} addToCart={addToCart} products={products} promotions={promotions} categories={categories} sections={homeSections} />
              </div>
            );
        case 'contact':
            return (
              <div key="contact">
                <ContactPage />
              </div>
            );
        case 'sourcing':
            return (
              <div key="sourcing" className="pt-40 md:pt-48">
                <SourcingRequestPage />
              </div>
            );
        case 'dashboard':
            return (
                <div key="dashboard" className="pt-40 md:pt-48">
                    <DashboardPage 
                        user={currentUser} products={products} showroomItems={showroomItems} promotions={promotions} categoryConfigs={DEFAULT_CATEGORIES}
                        systemStatus={systemStatus} isOnline={isOnline}
                        onAddProduct={async (p) => { setProducts([p, ...products]); return p; }}
                        onUpdateProduct={async (p) => { setProducts(prev => prev.map(x => x.id === p.id ? p : x)); return p; }}
                        onDeleteProduct={async (id) => { setProducts(products.filter(p=>p.id !== id)); return true; }}
                        onSetShowroomItems={()=>{}} onSetPromotions={()=>{}} onSetCategoryConfigs={()=>{}} setPage={setPage}
                        invoices={mockInvoices} payments={mockPayments} vipClients={vipClients} transactions={mockTransactions} onAddPayment={()=>{}}
                        onAddVipClient={async (c) => { setVipClients([...vipClients, c]); return c; }}
                        onUpdateVipClient={async (c) => { setVipClients(vipClients.map(v => v.id === c.id ? c : v)); return c; }}
                        onDeleteVipClient={async (id) => { setVipClients(vipClients.filter(v => v.id !== id)); return true; }}
                    />
                </div>
            );
        case 'dev_console':
            return (
                <div key="dev_console" className="pt-40 md:pt-48">
                    <DeveloperDashboard 
                        onBack={() => setPage('dashboard')}
                    />
                </div>
            );
        case 'login': 
            return (
              <div key="login">
                <LoginPage onLogin={async (c)=>{
                  const email = c.email.toLowerCase();
                  const password = c.password;

                  // Admin (SuperAdmin)
                  if (email === 'deltastars777@gmail.com' && password === 'Admin123!') {
                      setCurrentUser({ type: 'admin', email: email });
                      setPage('admin_dashboard');
                      return { success: true };
                  }

                  // Marketing
                  if (email === 'marketing@deltastars-ksa.com' && password === '***733691903***') {
                      setCurrentUser({ type: 'marketing', email: email });
                      setPage('dashboard');
                      return { success: true };
                  }

                  // Developer (Exclusive)
                  if ((email === 'vipservicesyemen@outlook.sa' || email === 'info@deltastars-ksa.com') && (password === '321666***' || password === '733691903***')) {
                      setCurrentUser({ type: 'developer', email: email });
                      setPage('dashboard');
                      return { success: true };
                  }

                  // Legacy / Master Passwords
                  const adminEmails = ['deltastars777@gmail.com', 'marketing@deltastars-ksa.com', 'info@deltastars-ksa.com', 'vipservicesyemen@outlook.sa'];
                  const isAuthorizedEmail = adminEmails.includes(email);
                  const isMasterPassword = ['Deltastar@', '321666', '733691903', '733691903***', '321666***', '***733691903***'].includes(password);

                  if (isAuthorizedEmail && isMasterPassword) {
                      setCurrentUser({ type: 'developer', email: email });
                      setPage('dashboard');
                      return { success: true };
                  }
                  return { success: false, error: 'بيانات الدخول غير صحيحة' };
                }} setPage={setPage} />
              </div>
            );
        case 'vipLogin': 
            return (
              <div key="vipLogin">
                <VipLoginPage onLogin={async (c)=>{
                    let client = vipClients.find(v => v.phone === c.phone);
                    
                    // If client doesn't exist, this is a new registration from VipLoginPage
                    if (!client) {
                        const newClient: VipClient = {
                            id: Date.now().toString(),
                            phone: c.phone,
                            companyName: `عميل جديد - ${c.phone}`,
                            contactPerson: 'مسؤول التواصل',
                            shippingAddress: 'المملكة العربية السعودية',
                            creditLimit: 5000,
                            currentBalance: 0
                        };
                        setVipClients(prev => [...prev, newClient]);
                        client = newClient;
                    }

                    // Check password (simple simulation)
                    // 'vip' is the bypass for biometric success
                    const isBioBypass = c.password === 'vip';
                    const isMasterPassword = c.password === '321666' || c.password === 'A12345a';
                    const isUserPassword = c.password && c.password.length >= 5;

                    if(client && (isBioBypass || isMasterPassword || isUserPassword)) {
                        setCurrentUser({ type: 'vip', phone: client.phone, name: client.companyName, creditLimit: client.creditLimit, currentBalance: client.currentBalance });
                        setPage('vipDashboard');
                        return { success: true };
                    }
                    return { success: false, error: 'بيانات العميل غير صحيحة' };
                }} setPage={setPage} />
              </div>
            );
        case 'vipDashboard': 
            return (
                <div key="vipDashboard" className="pt-40 md:pt-48">
                    <VipDashboardPage user={currentUser} onLogout={()=>{setCurrentUser(null); setPage('home')}} products={products} addToCart={addToCart} invoices={mockInvoices} transactions={mockTransactions} setPage={setPage} />
                </div>
            );
        case 'trackOrder': 
            return <div key="trackOrder" className="pt-40 md:pt-48"><OrderTrackingPage /></div>;
        case 'wishlist':
            return <div key="wishlist" className="pt-40 md:pt-48"><WishlistPage wishlist={wishlist} removeFromWishlist={(id) => setWishlist(wishlist.filter(p => p.id !== id))} addToCart={(p) => addToCart(p, 1)} setPage={setPage} /></div>;
        case 'products': 
            return <div key="products" className="pt-40 md:pt-48"><ProductsPage initialCategory={selectedFilterCategory} setPage={setPage} addToCart={addToCart} products={products} toggleWishlist={toggleWishlist} isProductInWishlist={isProductInWishlist} getAverageRating={getAverageRating} reviews={reviews} categories={categories} /></div>;
        case 'productDetail':
            const product = products.find(p => p.id === selectedProductId);
            if (!product) {
                setPage('products');
                return null;
            }
            return (
                <div key="productDetail" className="pt-40 md:pt-48">
                    <ProductDetailPage 
                        product={product} 
                        setPage={setPage} 
                        addToCart={addToCart}
                        reviews={getProductReviews(product.id)}
                        onAddReview={addReview}
                        averageRating={getAverageRating(product.id)}
                        toggleWishlist={toggleWishlist}
                        isInWishlist={isProductInWishlist(product.id)}
                    />
                </div>
            );
        case 'cart': 
            return <div key="cart" className="pt-40 md:pt-48"><CartPage cart={cart} removeFromCart={(id)=>setCart(cart.filter(i=>i.id!==id))} updateQuantity={(id,q)=>setCart(cart.map(i=>i.id===id?{...i,quantity:q}:i))} clearCart={()=>setCart([])} setPage={setPage} addPurchaseHistory={handleCheckoutComplete} /></div>;
        case 'privacy':
            return <div key="privacy"><LegalPages type="privacy" /></div>;
        case 'terms':
            return <div key="terms"><LegalPages type="terms" /></div>;
        case 'returns':
            return <div key="returns"><LegalPages type="returns" /></div>;
        case 'units':
            return <div key="units"><UnitsPage units={PRODUCT_UNITS} /></div>;
        case 'driverDashboard':
            return <div key="driverDashboard" className="pt-40 md:pt-48"><DriverDashboardPage setPage={setPage} /></div>;
        case 'admin_dashboard':
            return <div key="admin_dashboard" className="pt-40 md:pt-48"><AdminDashboard /></div>;
        default: 
            return (
              <div key="default">
                <Home setPage={setPage} addToCart={addToCart} products={products} promotions={promotions} categories={DEFAULT_CATEGORIES} sections={homeSections} />
              </div>
            );
      }
    } catch (e) {
      console.error("Page Render Error:", e);
      return null;
    }
  };

  // if (isInitializing) return <SplashScreen onComplete={() => setIsInitializing(false)} />;
  
  // Force initialization to false for debugging
  useEffect(() => {
    setIsInitializing(false);
  }, []);

  return (
    <ErrorBoundary>
      <div className="min-h-screen flex flex-col bg-white overflow-hidden selection:bg-secondary selection:text-white">
        {!isOnline && (
          <div className="fixed top-0 left-0 w-full bg-red-600 text-white py-2 px-4 z-[10000] text-center font-black text-sm animate-pulse flex items-center justify-center gap-3">
            <span className="w-2 h-2 bg-white rounded-full animate-ping"></span>
            {language === 'ar' ? 'أنت تتصفح الآن في وضع عدم الاتصال - قد تكون بعض الميزات محدودة' : 'You are currently offline - Some features may be limited'}
          </div>
        )}
        <Header 
          setPage={setPage} 
          cartItemCount={cart.reduce((s,i)=>s+i.quantity,0)} 
          wishlistItemCount={wishlist.length} 
          user={currentUser} 
          onLogout={()=>{setCurrentUser(null); setPage('home')}} 
          onToggleAiAssistant={() => setShowAi(!showAi)} 
        />
        <main className="flex-grow p-0 m-0 relative z-10">
          {renderPageContent()}
        </main>
        {showAi && <AiAssistant products={products} onClose={() => setShowAi(false)} />}
        
        <Footer setPage={setPage} />
        <PwaInstallPrompt />
      </div>
    </ErrorBoundary>
  );
}

export default function App() {
  return (
    <I18nProvider>
      <ToastProvider>
        <GeminiAiProvider>
          <FirebaseProvider>
            <MainApp />
            <ToastContainer />
          </FirebaseProvider>
        </GeminiAiProvider>
      </ToastProvider>
    </I18nProvider>
  );
}