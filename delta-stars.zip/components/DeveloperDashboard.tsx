
import React, { useState, useEffect } from 'react';
import { Product, Promotion, ShowroomItem, HomeSection, HomeSectionType, CategoryConfig, CategoryKey, ProductUnit, Branch, Order } from '../types';
import { useI18n } from './lib/contexts/I18nContext';
import { useToast } from './ToastContext';
import { 
    PlusIcon, TrashIcon, PencilIcon, SparklesIcon, 
    ChartBarIcon, FingerprintIcon, LogoutIcon, DocumentTextIcon,
    SettingsIcon, MapIcon, ShoppingBagIcon, EyeIcon, XIcon
} from './lib/contexts/Icons';
import api from './lib/api';
import { db, setDoc, doc, deleteDoc, collection, updateDoc } from '../firebase';
import { useFirebase } from './lib/contexts/FirebaseContext';

interface DeveloperDashboardProps {
    onBack: () => void;
}

export const DeveloperDashboard: React.FC<DeveloperDashboardProps> = ({ onBack }) => {
    const { language } = useI18n();
    const { addToast } = useToast();
    const { products, categories, units, homeSections, orders, branches } = useFirebase();
    const [tab, setTab] = useState<'products' | 'server' | 'database' | 'security' | 'sections' | 'categories' | 'units' | 'branches' | 'orders' | 'ai_insights' | 'financials'>('products');
    const [logs, setLogs] = useState<any[]>([]);
    const [editingProduct, setEditingProduct] = useState<Product | null>(null);
    const [newProduct, setNewProduct] = useState<Partial<Product>>({
        name_ar: '', name_en: '', category: 'vegetables', price: 0, image: '', unit_ar: 'ريال للكيلو', unit_en: 'kg', stock_quantity: 1000, min_threshold: 50, extra_settings: {}
    });

    const [editingCategory, setEditingCategory] = useState<CategoryConfig | null>(null);
    const [newCategory, setNewCategory] = useState<Partial<CategoryConfig>>({
        key: 'custom', label_ar: '', label_en: '', icon: '📦', order: 10, isVisible: true
    });

    const [editingUnit, setEditingUnit] = useState<ProductUnit | null>(null);
    const [newUnit, setNewUnit] = useState<Partial<ProductUnit>>({
        code: '', name_ar: '', name_en: '', base_factor: 1
    });

    const [editingBranch, setEditingBranch] = useState<Branch | null>(null);
    const [newBranch, setNewBranch] = useState<Partial<Branch>>({
        name_ar: '', name_en: '', address_ar: '', address_en: '', phone: '', city: ''
    });

    // Auto-save drafts to prevent data loss
    useEffect(() => {
        const draft = localStorage.getItem('dev_dashboard_drafts');
        if (draft) {
            try {
                const parsed = JSON.parse(draft);
                if (parsed.newProduct) setNewProduct(parsed.newProduct);
                if (parsed.editingProduct) setEditingProduct(parsed.editingProduct);
                if (parsed.newCategory) setNewCategory(parsed.newCategory);
                if (parsed.editingCategory) setEditingCategory(parsed.editingCategory);
                if (parsed.newUnit) setNewUnit(parsed.newUnit);
                if (parsed.editingUnit) setEditingUnit(parsed.editingUnit);
            } catch (e) {
                console.error('Failed to load drafts', e);
            }
        }
    }, []);

    useEffect(() => {
        const drafts = {
            newProduct,
            editingProduct,
            newCategory,
            editingCategory,
            newUnit,
            editingUnit
        };
        localStorage.setItem('dev_dashboard_drafts', JSON.stringify(drafts));
    }, [newProduct, editingProduct, newCategory, editingCategory, newUnit, editingUnit]);

    const handleSaveProduct = async () => {
        try {
            if (editingProduct) {
                await setDoc(doc(db, 'products', editingProduct.id.toString()), editingProduct);
                setEditingProduct(null);
                addToast('تم تحديث المنتج بنجاح', 'success');
            } else {
                const id = Math.max(0, ...products.map(p => p.id)) + 1;
                const productToAdd = { ...newProduct, id } as Product;
                await setDoc(doc(db, 'products', id.toString()), productToAdd);
                setNewProduct({ name_ar: '', name_en: '', category: 'vegetables', price: 0, image: '', unit_ar: 'ريال للكيلو', unit_en: 'kg', stock_quantity: 1000, min_threshold: 50 });
                addToast('تم إضافة المنتج بنجاح', 'success');
            }
            localStorage.removeItem('dev_dashboard_drafts');
        } catch (err) {
            addToast('فشل في حفظ المنتج', 'error');
        }
    };

    const handleDeleteProduct = async (id: number) => {
        if (window.confirm('هل أنت متأكد من حذف هذا المنتج؟')) {
            try {
                await deleteDoc(doc(db, 'products', id.toString()));
                addToast('تم حذف المنتج', 'info');
            } catch (err) {
                addToast('فشل في حذف المنتج', 'error');
            }
        }
    };

    const handleSaveCategory = async () => {
        try {
            if (editingCategory) {
                await setDoc(doc(db, 'categories', editingCategory.key), editingCategory);
                setEditingCategory(null);
                addToast('تم تحديث الصنف', 'success');
            } else {
                await setDoc(doc(db, 'categories', newCategory.key!), newCategory as CategoryConfig);
                setNewCategory({ key: 'custom', label_ar: '', label_en: '', icon: '📦', order: 10, isVisible: true });
                addToast('تم إضافة الصنف', 'success');
            }
        } catch (err) {
            addToast('فشل في حفظ الصنف', 'error');
        }
    };

    const handleSaveUnit = async () => {
        try {
            if (editingUnit) {
                await setDoc(doc(db, 'units', editingUnit.code), editingUnit);
                setEditingUnit(null);
                addToast('تم تحديث الوحدة', 'success');
            } else {
                await setDoc(doc(db, 'units', newUnit.code!), newUnit as ProductUnit);
                setNewUnit({ code: '', name_ar: '', name_en: '', base_factor: 1 });
                addToast('تم إضافة الوحدة', 'success');
            }
        } catch (err) {
            addToast('فشل في حفظ الوحدة', 'error');
        }
    };

    const handleSaveSection = async (section: HomeSection) => {
        try {
            await setDoc(doc(db, 'homeSections', section.id), section);
        } catch (err) {
            addToast('فشل في حفظ القسم', 'error');
        }
    };

    const handleDeleteSection = async (id: string) => {
        if (window.confirm('حذف هذا القسم؟')) {
            try {
                await deleteDoc(doc(db, 'homeSections', id));
                addToast('تم حذف القسم', 'info');
            } catch (err) {
                addToast('فشل في حذف القسم', 'error');
            }
        }
    };

    const handleSaveBranch = async () => {
        try {
            if (editingBranch) {
                await setDoc(doc(db, 'branches', editingBranch.id), editingBranch);
                setEditingBranch(null);
                addToast('تم تحديث الفرع بنجاح', 'success');
            } else {
                const id = newBranch.id || Math.random().toString(36).substr(2, 9);
                const branchToAdd = { ...newBranch, id } as Branch;
                await setDoc(doc(db, 'branches', id), branchToAdd);
                setNewBranch({ name_ar: '', name_en: '', address_ar: '', address_en: '', phone: '', city: '' });
                addToast('تم إضافة الفرع بنجاح', 'success');
            }
        } catch (err) {
            addToast('فشل في حفظ الفرع', 'error');
        }
    };

    const handleDeleteBranch = async (id: string) => {
        if (window.confirm('حذف هذا الفرع؟')) {
            try {
                await deleteDoc(doc(db, 'branches', id));
                addToast('تم حذف الفرع', 'info');
            } catch (err) {
                addToast('فشل في حذف الفرع', 'error');
            }
        }
    };

    const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
    const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);

    const handleViewOrder = (order: Order) => {
        setSelectedOrder(order);
        setIsOrderModalOpen(true);
    };

    const handleUpdateOrderStatus = async (orderId: string, status: Order['status']) => {
        try {
            await updateDoc(doc(db, 'orders', orderId), { status });
            addToast('تم تحديث حالة الطلب', 'success');
        } catch (err) {
            addToast('فشل في تحديث حالة الطلب', 'error');
        }
    };

    const handleAssignOrderToBranch = async (orderId: string, branchId: string) => {
        try {
            await updateDoc(doc(db, 'orders', orderId), { branchId });
            addToast('تم تعيين الفرع للطلب', 'success');
        } catch (err) {
            addToast('فشل في تعيين الفرع', 'error');
        }
    };

    useEffect(() => {
        const interval = setInterval(() => {
            setLogs(api.getSystemLogs());
        }, 1500);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="container mx-auto px-6 py-12 text-black animate-fade-in">
            <div className="bg-slate-900 text-white p-12 rounded-[4rem] shadow-4xl mb-12 flex flex-col md:flex-row justify-between items-center gap-8 border-b-[20px] border-secondary relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 blur-3xl rounded-full"></div>
                <div className="relative z-10 flex items-center gap-6">
                    <div className="w-20 h-20 bg-secondary/20 rounded-[2rem] flex items-center justify-center border border-white/20">
                        <SparklesIcon className="w-10 h-10 text-secondary" />
                    </div>
                    <div>
                        <h1 className="text-5xl font-black tracking-tighter uppercase">Delta Sovereign Hub</h1>
                        <p className="text-secondary font-bold text-[10px] tracking-[0.4em]">SYSTEM CORE v50.0 [RUST_ROCKET_NODE]</p>
                    </div>
                </div>
                <button onClick={onBack} className="relative z-10 bg-white/10 hover:bg-red-600 px-10 py-4 rounded-2xl font-black text-xl transition-all">إغلاق المحطة</button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
                <aside className="lg:col-span-3 space-y-4">
                    {[
                        { id: 'server', label: 'رادار العمليات', icon: '📡' },
                        { id: 'database', label: 'قاعدة البيانات SQL', icon: '🗄️' },
                        { id: 'security', label: 'الدرع الحيوي', icon: '🛡️' },
                        { id: 'ai_insights', label: language === 'ar' ? 'توقعات AI' : 'AI Insights', icon: '🧠' },
                        { id: 'financials', label: language === 'ar' ? 'التكامل المالي' : 'Financials', icon: '💰' },
                        { id: 'categories', label: 'إدارة الأصناف', icon: '🏷️' },
                        { id: 'units', label: 'إدارة الوحدات', icon: '⚖️' },
                        { id: 'products', label: 'إدارة المنتجات', icon: '🛒' },
                        { id: 'sections', label: 'إدارة الأقسام', icon: '🏗️' },
                        { id: 'branches', label: 'إدارة الفروع', icon: '📍' },
                        { id: 'orders', label: 'إدارة الطلبات', icon: '📦' }
                    ].map(t => (
                        <button 
                            key={t.id} onClick={() => setTab(t.id as any)}
                            className={`w-full p-8 rounded-[2.5rem] font-black text-2xl flex items-center gap-5 transition-all ${tab === t.id ? 'bg-primary text-white scale-105 shadow-xl' : 'bg-white text-slate-400 border border-gray-100'}`}
                        >
                            <span className="text-4xl">{t.icon}</span>
                            {t.label}
                        </button>
                    ))}
                </aside>

                <main className="lg:col-span-9 bg-white rounded-[4rem] shadow-2xl p-12 border border-gray-100 min-h-[700px]">
                    {tab === 'products' && (
                        <div className="space-y-12 animate-fade-in">
                            <div className="flex justify-between items-center">
                                <h2 className="text-4xl font-black text-slate-800 uppercase">Product Inventory Engine</h2>
                                <button 
                                    onClick={() => setEditingProduct(null)}
                                    className="bg-primary text-white px-8 py-4 rounded-2xl font-black flex items-center gap-3 hover:bg-secondary transition-all"
                                >
                                    <PlusIcon className="w-6 h-6" /> إضافة منتج جديد
                                </button>
                            </div>

                            <div className="bg-slate-50 p-10 rounded-[3rem] border-2 border-gray-100">
                                <h3 className="text-2xl font-black mb-8 text-primary">{editingProduct ? 'تعديل منتج' : 'إضافة منتج جديد'}</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">الاسم بالعربي</label>
                                        <input 
                                            type="text" 
                                            value={editingProduct ? editingProduct.name_ar : newProduct.name_ar}
                                            onChange={e => editingProduct ? setEditingProduct({...editingProduct, name_ar: e.target.value}) : setNewProduct({...newProduct, name_ar: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">Name in English</label>
                                        <input 
                                            type="text" 
                                            value={editingProduct ? editingProduct.name_en : newProduct.name_en}
                                            onChange={e => editingProduct ? setEditingProduct({...editingProduct, name_en: e.target.value}) : setNewProduct({...newProduct, name_en: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">السعر</label>
                                        <input 
                                            type="number" 
                                            value={editingProduct ? editingProduct.price : newProduct.price}
                                            onChange={e => editingProduct ? setEditingProduct({...editingProduct, price: parseFloat(e.target.value)}) : setNewProduct({...newProduct, price: parseFloat(e.target.value)})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">رابط الصورة (Drive ID)</label>
                                        <input 
                                            type="text" 
                                            value={editingProduct ? editingProduct.image : newProduct.image}
                                            onChange={e => editingProduct ? setEditingProduct({...editingProduct, image: e.target.value}) : setNewProduct({...newProduct, image: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">الوحدة (عربي)</label>
                                        <input 
                                            type="text" 
                                            value={editingProduct ? editingProduct.unit_ar : newProduct.unit_ar}
                                            onChange={e => editingProduct ? setEditingProduct({...editingProduct, unit_ar: e.target.value}) : setNewProduct({...newProduct, unit_ar: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">Unit (EN)</label>
                                        <input 
                                            type="text" 
                                            value={editingProduct ? editingProduct.unit_en : newProduct.unit_en}
                                            onChange={e => editingProduct ? setEditingProduct({...editingProduct, unit_en: e.target.value}) : setNewProduct({...newProduct, unit_en: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">الكمية في المخزن</label>
                                        <input 
                                            type="number" 
                                            value={editingProduct ? editingProduct.stock_quantity : newProduct.stock_quantity}
                                            onChange={e => editingProduct ? setEditingProduct({...editingProduct, stock_quantity: parseInt(e.target.value)}) : setNewProduct({...newProduct, stock_quantity: parseInt(e.target.value)})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">حد التنبيه الأدنى</label>
                                        <input 
                                            type="number" 
                                            value={editingProduct ? editingProduct.min_threshold : newProduct.min_threshold}
                                            onChange={e => editingProduct ? setEditingProduct({...editingProduct, min_threshold: parseInt(e.target.value)}) : setNewProduct({...newProduct, min_threshold: parseInt(e.target.value)})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2 md:col-span-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">الوصف (عربي)</label>
                                        <textarea 
                                            value={editingProduct ? editingProduct.description_ar : newProduct.description_ar}
                                            onChange={e => editingProduct ? setEditingProduct({...editingProduct, description_ar: e.target.value}) : setNewProduct({...newProduct, description_ar: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm h-24"
                                        />
                                    </div>
                                    <div className="space-y-2 md:col-span-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">Description (EN)</label>
                                        <textarea 
                                            value={editingProduct ? editingProduct.description_en : newProduct.description_en}
                                            onChange={e => editingProduct ? setEditingProduct({...editingProduct, description_en: e.target.value}) : setNewProduct({...newProduct, description_en: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm h-24"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">المميزات (عربي)</label>
                                        <input 
                                            type="text" 
                                            value={editingProduct ? editingProduct.features_ar : newProduct.features_ar}
                                            onChange={e => editingProduct ? setEditingProduct({...editingProduct, features_ar: e.target.value}) : setNewProduct({...newProduct, features_ar: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">Features (EN)</label>
                                        <input 
                                            type="text" 
                                            value={editingProduct ? editingProduct.features_en : newProduct.features_en}
                                            onChange={e => editingProduct ? setEditingProduct({...editingProduct, features_en: e.target.value}) : setNewProduct({...newProduct, features_en: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">المنشأ (عربي)</label>
                                        <input 
                                            type="text" 
                                            value={editingProduct ? editingProduct.origin_ar : newProduct.origin_ar}
                                            onChange={e => editingProduct ? setEditingProduct({...editingProduct, origin_ar: e.target.value}) : setNewProduct({...newProduct, origin_ar: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">Origin (EN)</label>
                                        <input 
                                            type="text" 
                                            value={editingProduct ? editingProduct.origin_en : newProduct.origin_en}
                                            onChange={e => editingProduct ? setEditingProduct({...editingProduct, origin_en: e.target.value}) : setNewProduct({...newProduct, origin_en: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">التصنيف</label>
                                        <select 
                                            value={editingProduct ? editingProduct.category : newProduct.category}
                                            onChange={e => editingProduct ? setEditingProduct({...editingProduct, category: e.target.value as CategoryKey}) : setNewProduct({...newProduct, category: e.target.value as CategoryKey})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        >
                                            {categories.map(c => (
                                                <option key={c.key} value={c.key}>{language === 'ar' ? c.label_ar : c.label_en}</option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">الوحدة (Unit)</label>
                                        <select 
                                            value={editingProduct ? units.find(u => u.name_ar === editingProduct.unit_ar)?.code || '' : units.find(u => u.name_ar === newProduct.unit_ar)?.code || ''}
                                            onChange={e => {
                                                const unit = units.find(u => u.code === e.target.value);
                                                if (unit) {
                                                    if (editingProduct) {
                                                        setEditingProduct({...editingProduct, unit_ar: unit.name_ar, unit_en: unit.name_en});
                                                    } else {
                                                        setNewProduct({...newProduct, unit_ar: unit.name_ar, unit_en: unit.name_en});
                                                    }
                                                }
                                            }}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        >
                                            <option value="">اختر الوحدة</option>
                                            {units.map(u => (
                                                <option key={u.code} value={u.code}>{language === 'ar' ? u.name_ar : u.name_en}</option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="space-y-2 md:col-span-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">إعدادات إضافية (JSON)</label>
                                        <textarea 
                                            value={JSON.stringify(editingProduct ? editingProduct.extra_settings : newProduct.extra_settings, null, 2)}
                                            onChange={e => {
                                                try {
                                                    const val = JSON.parse(e.target.value);
                                                    editingProduct ? setEditingProduct({...editingProduct, extra_settings: val}) : setNewProduct({...newProduct, extra_settings: val});
                                                } catch (err) {}
                                            }}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-mono text-sm outline-none shadow-sm h-32"
                                            placeholder='{"color": "red", "size": "large"}'
                                        />
                                    </div>
                                </div>
                                <button 
                                    onClick={handleSaveProduct}
                                    className="w-full mt-10 py-6 bg-secondary text-white rounded-2xl font-black text-xl shadow-xl hover:scale-[1.02] transition-all"
                                >
                                    {editingProduct ? 'حفظ التغييرات' : 'إضافة للمخزون السيادي'}
                                </button>
                            </div>

                            <div className="space-y-6">
                                <h3 className="text-2xl font-black text-slate-400 uppercase tracking-widest">Current Inventory ({products.length})</h3>
                                <div className="grid grid-cols-1 gap-4">
                                    {products.slice(0, 10).map(p => (
                                        <div key={p.id} className="bg-white p-6 rounded-3xl border border-gray-100 flex items-center justify-between group hover:shadow-xl transition-all">
                                            <div className="flex items-center gap-6">
                                                <img src={p.image} className="w-16 h-16 rounded-xl object-cover" alt="" />
                                                <div>
                                                    <h4 className="font-black text-xl text-primary">{p.name_ar}</h4>
                                                    <p className="text-xs font-bold text-gray-400">{p.name_en} • {p.price} SAR</p>
                                                </div>
                                            </div>
                                            <div className="flex gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
                                                <button onClick={() => setEditingProduct(p)} className="p-3 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-600 hover:text-white transition-all"><PencilIcon className="w-5 h-5" /></button>
                                                <button onClick={() => handleDeleteProduct(p.id)} className="p-3 bg-red-50 text-red-600 rounded-xl hover:bg-red-600 hover:text-white transition-all"><TrashIcon className="w-5 h-5" /></button>
                                            </div>
                                        </div>
                                    ))}
                                    {products.length > 10 && <p className="text-center text-gray-400 font-bold py-4 italic">... and {products.length - 10} more items</p>}
                                </div>
                            </div>
                        </div>
                    )}

                    {tab === 'sections' && (
                        <div className="space-y-12 animate-fade-in">
                            <div className="flex justify-between items-center">
                                <h2 className="text-4xl font-black text-slate-800 uppercase">Home Section Orchestrator</h2>
                                <button 
                                    onClick={() => {
                                        const id = `section-${Date.now()}`;
                                        handleSaveSection({ id, type: 'hero', title_ar: 'قسم جديد', title_en: 'New Section', isVisible: true, order: homeSections.length + 1 });
                                    }}
                                    className="bg-primary text-white px-8 py-4 rounded-2xl font-black flex items-center gap-3 hover:bg-secondary transition-all"
                                >
                                    <PlusIcon className="w-6 h-6" /> إضافة قسم جديد
                                </button>
                            </div>

                            <div className="space-y-6">
                                {homeSections.sort((a, b) => a.order - b.order).map((section, index) => (
                                    <div key={section.id} className="bg-slate-50 p-8 rounded-[3rem] border-2 border-gray-100 flex flex-col md:flex-row gap-8 items-center">
                                        <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-6 w-full">
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">نوع القسم</label>
                                                <select 
                                                    value={section.type}
                                                    onChange={e => handleSaveSection({ ...section, type: e.target.value as HomeSectionType })}
                                                    className="w-full p-4 bg-white border-2 border-transparent focus:border-primary rounded-xl font-bold outline-none shadow-sm"
                                                >
                                                    <option value="hero">Hero Banner</option>
                                                    <option value="categories">Categories</option>
                                                    <option value="partners">Partners</option>
                                                    <option value="trust">Trust & Verification</option>
                                                    <option value="channels">Channels</option>
                                                </select>
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">العنوان (عربي)</label>
                                                <input 
                                                    type="text"
                                                    value={section.title_ar}
                                                    onChange={e => handleSaveSection({ ...section, title_ar: e.target.value })}
                                                    className="w-full p-4 bg-white border-2 border-transparent focus:border-primary rounded-xl font-bold outline-none shadow-sm"
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">Title (EN)</label>
                                                <input 
                                                    type="text"
                                                    value={section.title_en}
                                                    onChange={e => handleSaveSection({ ...section, title_en: e.target.value })}
                                                    className="w-full p-4 bg-white border-2 border-transparent focus:border-primary rounded-xl font-bold outline-none shadow-sm"
                                                />
                                            </div>
                                        </div>
                                        
                                        <div className="flex items-center gap-4">
                                            <button 
                                                onClick={() => handleSaveSection({ ...section, isVisible: !section.isVisible })}
                                                className={`p-4 rounded-xl font-black transition-all ${section.isVisible ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'}`}
                                            >
                                                {section.isVisible ? 'ظاهر' : 'مخفي'}
                                            </button>
                                            <div className="flex flex-col gap-2">
                                                <button 
                                                    disabled={index === 0}
                                                    onClick={() => {
                                                        const newSections = [...homeSections];
                                                        const prev = newSections.find(s => s.order === section.order - 1);
                                                        if (prev) {
                                                            handleSaveSection({ ...prev, order: prev.order + 1 });
                                                            handleSaveSection({ ...section, order: section.order - 1 });
                                                        }
                                                    }}
                                                    className="p-2 bg-white border border-gray-200 rounded-lg hover:bg-primary hover:text-white disabled:opacity-30"
                                                >
                                                    ▲
                                                </button>
                                                <button 
                                                    disabled={index === homeSections.length - 1}
                                                    onClick={() => {
                                                        const newSections = [...homeSections];
                                                        const next = newSections.find(s => s.order === section.order + 1);
                                                        if (next) {
                                                            handleSaveSection({ ...next, order: next.order - 1 });
                                                            handleSaveSection({ ...section, order: section.order + 1 });
                                                        }
                                                    }}
                                                    className="p-2 bg-white border border-gray-200 rounded-lg hover:bg-primary hover:text-white disabled:opacity-30"
                                                >
                                                    ▼
                                                </button>
                                            </div>
                                            <button 
                                                onClick={() => handleDeleteSection(section.id)}
                                                className="p-4 bg-red-50 text-red-600 rounded-xl hover:bg-red-600 hover:text-white transition-all"
                                            >
                                                <TrashIcon className="w-6 h-6" />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {tab === 'categories' && (
                        <div className="space-y-12 animate-fade-in">
                            <div className="flex justify-between items-center">
                                <h2 className="text-4xl font-black text-slate-800 uppercase">Category Architect</h2>
                                <button 
                                    onClick={() => setEditingCategory(null)}
                                    className="bg-primary text-white px-8 py-4 rounded-2xl font-black flex items-center gap-3 hover:bg-secondary transition-all"
                                >
                                    <PlusIcon className="w-6 h-6" /> إضافة صنف جديد
                                </button>
                            </div>

                            <div className="bg-slate-50 p-10 rounded-[3rem] border-2 border-gray-100">
                                <h3 className="text-2xl font-black mb-8 text-primary">{editingCategory ? 'تعديل صنف' : 'إضافة صنف جديد'}</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">مفتاح الصنف (Unique Key)</label>
                                        <input 
                                            type="text" 
                                            value={editingCategory ? editingCategory.key : newCategory.key}
                                            onChange={e => editingCategory ? setEditingCategory({...editingCategory, key: e.target.value as CategoryKey}) : setNewCategory({...newCategory, key: e.target.value as CategoryKey})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">الأيقونة (Emoji)</label>
                                        <input 
                                            type="text" 
                                            value={editingCategory ? editingCategory.icon : newCategory.icon}
                                            onChange={e => editingCategory ? setEditingCategory({...editingCategory, icon: e.target.value}) : setNewCategory({...newCategory, icon: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">الاسم بالعربي</label>
                                        <input 
                                            type="text" 
                                            value={editingCategory ? editingCategory.label_ar : newCategory.label_ar}
                                            onChange={e => editingCategory ? setEditingCategory({...editingCategory, label_ar: e.target.value}) : setNewCategory({...newCategory, label_ar: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">Name in English</label>
                                        <input 
                                            type="text" 
                                            value={editingCategory ? editingCategory.label_en : newCategory.label_en}
                                            onChange={e => editingCategory ? setEditingCategory({...editingCategory, label_en: e.target.value}) : setNewCategory({...newCategory, label_en: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                </div>
                                <button 
                                    onClick={handleSaveCategory}
                                    className="w-full mt-10 py-6 bg-secondary text-white rounded-2xl font-black text-xl shadow-xl hover:scale-[1.02] transition-all"
                                >
                                    {editingCategory ? 'حفظ التغييرات' : 'إضافة صنف'}
                                </button>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {categories.map(c => (
                                    <div key={c.key} className="bg-white p-8 rounded-[2.5rem] border border-gray-100 flex items-center justify-between group hover:shadow-xl transition-all">
                                        <div className="flex items-center gap-4">
                                            <span className="text-4xl">{c.icon}</span>
                                            <div>
                                                <h4 className="font-black text-xl text-primary">{c.label_ar}</h4>
                                                <p className="text-xs font-bold text-gray-400">{c.label_en}</p>
                                            </div>
                                        </div>
                                        <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                            <button onClick={() => setEditingCategory(c)} className="p-3 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-600 hover:text-white transition-all"><PencilIcon className="w-5 h-5" /></button>
                                            <button onClick={async () => {
                                                if (window.confirm('حذف هذا الصنف؟')) {
                                                    try {
                                                        await deleteDoc(doc(db, 'categories', c.key));
                                                        addToast('تم حذف الصنف', 'info');
                                                    } catch (err) {
                                                        addToast('فشل في حذف الصنف', 'error');
                                                    }
                                                }
                                            }} className="p-3 bg-red-50 text-red-600 rounded-xl hover:bg-red-600 hover:text-white transition-all"><TrashIcon className="w-5 h-5" /></button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {tab === 'units' && (
                        <div className="space-y-12 animate-fade-in">
                            <div className="flex justify-between items-center">
                                <h2 className="text-4xl font-black text-slate-800 uppercase">Unit Master</h2>
                                <button 
                                    onClick={() => setEditingUnit(null)}
                                    className="bg-primary text-white px-8 py-4 rounded-2xl font-black flex items-center gap-3 hover:bg-secondary transition-all"
                                >
                                    <PlusIcon className="w-6 h-6" /> إضافة وحدة جديدة
                                </button>
                            </div>

                            <div className="bg-slate-50 p-10 rounded-[3rem] border-2 border-gray-100">
                                <h3 className="text-2xl font-black mb-8 text-primary">{editingUnit ? 'تعديل وحدة' : 'إضافة وحدة جديدة'}</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">كود الوحدة (Code)</label>
                                        <input 
                                            type="text" 
                                            value={editingUnit ? editingUnit.code : newUnit.code}
                                            onChange={e => editingUnit ? setEditingUnit({...editingUnit, code: e.target.value}) : setNewUnit({...newUnit, code: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">عامل الأساس (Base Factor)</label>
                                        <input 
                                            type="number" 
                                            value={editingUnit ? editingUnit.base_factor : newUnit.base_factor}
                                            onChange={e => editingUnit ? setEditingUnit({...editingUnit, base_factor: parseFloat(e.target.value)}) : setNewUnit({...newUnit, base_factor: parseFloat(e.target.value)})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">الاسم بالعربي</label>
                                        <input 
                                            type="text" 
                                            value={editingUnit ? editingUnit.name_ar : newUnit.name_ar}
                                            onChange={e => editingUnit ? setEditingUnit({...editingUnit, name_ar: e.target.value}) : setNewUnit({...newUnit, name_ar: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">Name in English</label>
                                        <input 
                                            type="text" 
                                            value={editingUnit ? editingUnit.name_en : newUnit.name_en}
                                            onChange={e => editingUnit ? setEditingUnit({...editingUnit, name_en: e.target.value}) : setNewUnit({...newUnit, name_en: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                </div>
                                <button 
                                    onClick={handleSaveUnit}
                                    className="w-full mt-10 py-6 bg-secondary text-white rounded-2xl font-black text-xl shadow-xl hover:scale-[1.02] transition-all"
                                >
                                    {editingUnit ? 'حفظ التغييرات' : 'إضافة وحدة'}
                                </button>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {units.map(u => (
                                    <div key={u.code} className="bg-white p-8 rounded-[2.5rem] border border-gray-100 flex items-center justify-between group hover:shadow-xl transition-all">
                                        <div className="flex items-center gap-4">
                                            <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center font-black text-primary">{u.code}</div>
                                            <div>
                                                <h4 className="font-black text-xl text-primary">{u.name_ar}</h4>
                                                <p className="text-xs font-bold text-gray-400">{u.name_en} • Factor: {u.base_factor}</p>
                                            </div>
                                        </div>
                                        <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                            <button onClick={() => setEditingUnit(u)} className="p-3 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-600 hover:text-white transition-all"><PencilIcon className="w-5 h-5" /></button>
                                            <button onClick={async () => {
                                                if (window.confirm('حذف هذه الوحدة؟')) {
                                                    try {
                                                        await deleteDoc(doc(db, 'units', u.code));
                                                        addToast('تم حذف الوحدة', 'info');
                                                    } catch (err) {
                                                        addToast('فشل في حذف الوحدة', 'error');
                                                    }
                                                }
                                            }} className="p-3 bg-red-50 text-red-600 rounded-xl hover:bg-red-600 hover:text-white transition-all"><TrashIcon className="w-5 h-5" /></button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {tab === 'branches' && (
                        <div className="space-y-12 animate-fade-in">
                            <div className="flex justify-between items-center">
                                <h2 className="text-4xl font-black text-slate-800 uppercase">Branch Network</h2>
                                <button 
                                    onClick={() => setEditingBranch(null)}
                                    className="bg-primary text-white px-8 py-4 rounded-2xl font-black flex items-center gap-3 hover:bg-secondary transition-all"
                                >
                                    <PlusIcon className="w-6 h-6" /> إضافة فرع جديد
                                </button>
                            </div>

                            <div className="bg-slate-50 p-10 rounded-[3rem] border-2 border-gray-100">
                                <h3 className="text-2xl font-black mb-8 text-primary">{editingBranch ? 'تعديل فرع' : 'إضافة فرع جديد'}</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">رقم الفرع (ID)</label>
                                        <input 
                                            type="text" 
                                            value={editingBranch ? editingBranch.id : newBranch.id || ''}
                                            onChange={e => editingBranch ? setEditingBranch({...editingBranch, id: e.target.value}) : setNewBranch({...newBranch, id: e.target.value})}
                                            placeholder="مثال: 0202"
                                            disabled={!!editingBranch}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm disabled:bg-gray-50"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">اسم الفرع (عربي)</label>
                                        <input 
                                            type="text" 
                                            value={editingBranch ? editingBranch.name_ar : newBranch.name_ar}
                                            onChange={e => editingBranch ? setEditingBranch({...editingBranch, name_ar: e.target.value}) : setNewBranch({...newBranch, name_ar: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">Branch Name (EN)</label>
                                        <input 
                                            type="text" 
                                            value={editingBranch ? editingBranch.name_en : newBranch.name_en}
                                            onChange={e => editingBranch ? setEditingBranch({...editingBranch, name_en: e.target.value}) : setNewBranch({...newBranch, name_en: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">المدينة</label>
                                        <input 
                                            type="text" 
                                            value={editingBranch ? editingBranch.city : newBranch.city}
                                            onChange={e => editingBranch ? setEditingBranch({...editingBranch, city: e.target.value}) : setNewBranch({...newBranch, city: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">رقم الهاتف</label>
                                        <input 
                                            type="text" 
                                            value={editingBranch ? editingBranch.phone : newBranch.phone}
                                            onChange={e => editingBranch ? setEditingBranch({...editingBranch, phone: e.target.value}) : setNewBranch({...newBranch, phone: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">العنوان (عربي)</label>
                                        <input 
                                            type="text" 
                                            value={editingBranch ? editingBranch.address_ar : newBranch.address_ar}
                                            onChange={e => editingBranch ? setEditingBranch({...editingBranch, address_ar: e.target.value}) : setNewBranch({...newBranch, address_ar: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">Address (EN)</label>
                                        <input 
                                            type="text" 
                                            value={editingBranch ? editingBranch.address_en : newBranch.address_en}
                                            onChange={e => editingBranch ? setEditingBranch({...editingBranch, address_en: e.target.value}) : setNewBranch({...newBranch, address_en: e.target.value})}
                                            className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm"
                                        />
                                    </div>
                                </div>
                                <button 
                                    onClick={handleSaveBranch}
                                    className="w-full mt-10 py-6 bg-secondary text-white rounded-2xl font-black text-xl shadow-xl hover:scale-[1.02] transition-all"
                                >
                                    {editingBranch ? 'حفظ التغييرات' : 'إضافة فرع'}
                                </button>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {branches.map(b => (
                                    <div key={b.id} className="bg-white p-8 rounded-[2.5rem] border border-gray-100 flex items-center justify-between group hover:shadow-xl transition-all">
                                        <div className="flex items-center gap-4">
                                            <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center font-black text-primary">📍</div>
                                            <div>
                                                <h4 className="font-black text-xl text-primary">{b.name_ar}</h4>
                                                <p className="text-xs font-bold text-gray-400">{b.city} • {b.phone}</p>
                                            </div>
                                        </div>
                                        <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                            <button onClick={() => setEditingBranch(b)} className="p-3 bg-blue-50 text-blue-600 rounded-xl hover:bg-blue-600 hover:text-white transition-all"><PencilIcon className="w-5 h-5" /></button>
                                            <button onClick={() => handleDeleteBranch(b.id)} className="p-3 bg-red-50 text-red-600 rounded-xl hover:bg-red-600 hover:text-white transition-all"><TrashIcon className="w-5 h-5" /></button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {tab === 'orders' && (
                        <div className="space-y-12 animate-fade-in">
                            <h2 className="text-4xl font-black text-slate-800 uppercase">Order Command Center</h2>
                            
                            <div className="bg-white rounded-[3rem] border-2 border-gray-100 overflow-hidden shadow-sm">
                                <table className="w-full text-right">
                                    <thead className="bg-slate-50 border-b-2 border-gray-100">
                                        <tr>
                                            <th className="p-6 font-black text-primary uppercase tracking-widest text-xs">رقم الطلب</th>
                                            <th className="p-6 font-black text-primary uppercase tracking-widest text-xs">العميل</th>
                                            <th className="p-6 font-black text-primary uppercase tracking-widest text-xs">التاريخ</th>
                                            <th className="p-6 font-black text-primary uppercase tracking-widest text-xs">المبلغ</th>
                                            <th className="p-6 font-black text-primary uppercase tracking-widest text-xs">الحالة</th>
                                            <th className="p-6 font-black text-primary uppercase tracking-widest text-xs">الفرع</th>
                                            <th className="p-6 font-black text-primary uppercase tracking-widest text-xs">إجراءات</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-100">
                                        {orders.map(order => (
                                            <tr key={order.id} className="hover:bg-slate-50 transition-all">
                                                <td className="p-6 font-black text-slate-800">#{order.id.slice(-6)}</td>
                                                <td className="p-6 font-bold text-slate-600">{order.customerName || 'عميل VIP'}</td>
                                                <td className="p-6 text-sm text-gray-400 font-bold">{new Date(order.createdAt).toLocaleDateString('ar-SA')}</td>
                                                <td className="p-6 font-black text-secondary">{order.total} ر.س</td>
                                                <td className="p-6">
                                                    <select 
                                                        value={order.status}
                                                        onChange={e => handleUpdateOrderStatus(order.id, e.target.value as any)}
                                                        className={`p-2 rounded-lg font-black text-xs border-2 ${
                                                            order.status === 'delivered' ? 'bg-green-50 text-green-600 border-green-100' :
                                                            order.status === 'cancelled' ? 'bg-red-50 text-red-600 border-red-100' :
                                                            'bg-blue-50 text-blue-600 border-blue-100'
                                                        }`}
                                                    >
                                                        <option value="pending">قيد الانتظار</option>
                                                        <option value="processing">قيد التجهيز</option>
                                                        <option value="shipped">قيد الشحن</option>
                                                        <option value="delivered">تم التسليم</option>
                                                        <option value="cancelled">ملغي</option>
                                                    </select>
                                                </td>
                                                <td className="p-6">
                                                    <select 
                                                        value={order.branchId || ''}
                                                        onChange={e => handleAssignOrderToBranch(order.id, e.target.value)}
                                                        className="p-2 bg-white border border-gray-200 rounded-lg text-xs font-bold"
                                                    >
                                                        <option value="">غير محدد</option>
                                                        {branches.map(b => (
                                                            <option key={b.id} value={b.id}>{b.name_ar}</option>
                                                        ))}
                                                    </select>
                                                </td>
                                                <td className="p-6">
                                                    <button 
                                                        onClick={() => handleViewOrder(order)}
                                                        className="p-3 bg-slate-100 text-slate-600 rounded-xl hover:bg-primary hover:text-white transition-all"
                                                    >
                                                        <EyeIcon className="w-5 h-5" />
                                                    </button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}

                    {tab === 'server' && (
                        <div className="flex flex-col h-full animate-fade-in">
                            <h2 className="text-3xl font-black text-slate-800 mb-8 uppercase">Live Rocket Node Radar</h2>
                            <div className="bg-slate-950 rounded-3xl p-8 font-mono text-sm overflow-y-auto flex-1 h-[500px] border-4 border-slate-900 shadow-inner">
                                {logs.length === 0 ? <p className="text-slate-600 italic">Listening for requests...</p> : logs.map(log => (
                                    <div key={log.id} className="mb-4 border-b border-slate-900 pb-4">
                                        <div className="flex justify-between mb-2">
                                            <span className="text-green-400 font-black">[{log.level}] {log.action}</span>
                                            <span className="text-slate-500">{log.timestamp}</span>
                                        </div>
                                        <p className="text-blue-300">{log.detail}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {tab === 'database' && (
                        <div className="space-y-8 animate-fade-in-up">
                            <h2 className="text-3xl font-black text-slate-800 uppercase">Sovereign SQL Schema Explorer</h2>
                            <div className="bg-slate-50 p-10 rounded-3xl border-2 border-gray-100 font-mono text-sm overflow-x-auto text-primary">
                                <pre className="leading-loose">
{`CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  phone VARCHAR(15) UNIQUE,
  phone_verified BOOLEAN DEFAULT FALSE
);

CREATE TABLE otp_requests (
  id UUID PRIMARY KEY,
  otp_hash TEXT NOT NULL,
  is_used BOOLEAN DEFAULT FALSE
);

CREATE TABLE units (
  code VARCHAR(10) PRIMARY KEY,
  name_ar VARCHAR(50) NOT NULL,
  name_en VARCHAR(50) NOT NULL,
  base_factor DECIMAL(10,2) NOT NULL
);

INSERT INTO units (code, name_ar, name_en, base_factor) VALUES
('G',     'جرام',      'Gram',      1),
('KG',    'كيلو',      'Kilogram',  1000),
('500G',  '500 جرام',  '500 Grams', 500),
('BUNCH', 'حزمة',      'Bunch',     250),
('PACK',  'باكت',      'Pack',      1000);`}
                                </pre>
                            </div>
                            <div className="bg-secondary/10 p-6 rounded-2xl border-2 border-secondary/20 flex items-center gap-4">
                                <div className="w-4 h-4 bg-secondary rounded-full animate-ping"></div>
                                <p className="text-secondary font-black text-sm uppercase tracking-widest">Active Migration: v50.0_initial_sovereign</p>
                            </div>
                        </div>
                    )}

                    {tab === 'security' && (
                        <div className="space-y-12 animate-fade-in">
                            <h2 className="text-4xl font-black text-slate-800 uppercase flex items-center gap-4">
                                <FingerprintIcon className="w-10 h-10 text-primary" />
                                {language === 'ar' ? 'نظام الحماية السيادي' : 'Sovereign Security Protocols'}
                            </h2>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                                <div className="bg-slate-50 p-10 rounded-[3rem] border-2 border-gray-100 space-y-8">
                                    <h3 className="text-2xl font-black text-primary">{language === 'ar' ? 'تغيير كلمة مرور المطور' : 'Change Developer Password'}</h3>
                                    <div className="space-y-4">
                                        <div className="space-y-2">
                                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">{language === 'ar' ? 'كلمة المرور الجديدة' : 'New Password'}</label>
                                            <input type="password" placeholder="••••••••" className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm" />
                                        </div>
                                        <div className="space-y-2">
                                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-4">{language === 'ar' ? 'تأكيد كلمة المرور' : 'Confirm Password'}</label>
                                            <input type="password" placeholder="••••••••" className="w-full p-5 bg-white border-2 border-transparent focus:border-primary rounded-2xl font-bold outline-none shadow-sm" />
                                        </div>
                                        <button className="w-full py-5 bg-primary text-white rounded-2xl font-black text-xl shadow-lg hover:bg-secondary transition-all">
                                            {language === 'ar' ? 'تحديث مفتاح الوصول السيادي' : 'Update Sovereign Access Key'}
                                        </button>
                                    </div>
                                </div>

                                <div className="bg-slate-50 p-10 rounded-[3rem] border-2 border-gray-100 space-y-8">
                                    <h3 className="text-2xl font-black text-primary">{language === 'ar' ? 'المصادقة الثنائية (MFA)' : 'Biometric Authentication'}</h3>
                                    <div className="flex items-center justify-between p-6 bg-white rounded-2xl border border-gray-100">
                                        <div>
                                            <p className="font-black text-slate-800">{language === 'ar' ? 'بصمة الإصبع' : 'Fingerprint'}</p>
                                            <p className="text-xs text-gray-400 font-bold">{language === 'ar' ? 'تفعيل الدخول عبر البصمة' : 'Enable Biometric Access'}</p>
                                        </div>
                                        <div className="w-16 h-8 bg-primary rounded-full relative cursor-pointer">
                                            <div className="absolute right-1 top-1 w-6 h-6 bg-white rounded-full shadow-sm"></div>
                                        </div>
                                    </div>
                                    <div className="flex items-center justify-between p-6 bg-white rounded-2xl border border-gray-100">
                                        <div>
                                            <p className="font-black text-slate-800">{language === 'ar' ? 'التعرف على الوجه' : 'Face Recognition'}</p>
                                            <p className="text-xs text-gray-400 font-bold">{language === 'ar' ? 'تفعيل الدخول عبر الوجه' : 'Enable Face ID'}</p>
                                        </div>
                                        <div className="w-16 h-8 bg-gray-200 rounded-full relative cursor-pointer">
                                            <div className="absolute left-1 top-1 w-6 h-6 bg-white rounded-full shadow-sm"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="bg-red-50 p-10 rounded-[3rem] border-2 border-red-100">
                                <h3 className="text-2xl font-black text-red-600 mb-6 uppercase tracking-tighter">Emergency Lockdown</h3>
                                <p className="text-red-400 font-bold mb-8">{language === 'ar' ? 'في حالة اكتشاف اختراق، سيتم إغلاق كافة قنوات التوريد وتشفير قاعدة البيانات فوراً.' : 'In case of breach detection, all supply channels will be closed and DB encrypted immediately.'}</p>
                                <button className="px-12 py-5 bg-red-600 text-white rounded-2xl font-black text-xl shadow-xl hover:bg-red-700 transition-all">
                                    {language === 'ar' ? 'تفعيل الإغلاق الشامل' : 'Activate Total Lockdown'}
                                </button>
                            </div>
                        </div>
                    )}

                    {tab === 'ai_insights' && (
                        <div className="space-y-12 animate-fade-in">
                            <h2 className="text-4xl font-black text-slate-800 uppercase flex items-center gap-4">
                                <SparklesIcon className="w-10 h-10 text-primary" />
                                {language === 'ar' ? 'توقعات الذكاء الاصطناعي' : 'AI Predictive Insights'}
                            </h2>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                                <div className="p-10 bg-blue-50 rounded-[3rem] border-2 border-blue-100">
                                    <p className="text-blue-600 font-black text-xs uppercase tracking-widest mb-4">توقع الطلب</p>
                                    <p className="text-4xl font-black text-slate-800">+15%</p>
                                    <p className="text-sm font-bold text-gray-500 mt-2">زيادة متوقعة في طلبات الخضروات الورقية للأسبوع القادم</p>
                                </div>
                                <div className="p-10 bg-green-50 rounded-[3rem] border-2 border-green-100">
                                    <p className="text-green-600 font-black text-xs uppercase tracking-widest mb-4">تحسين المخزون</p>
                                    <p className="text-4xl font-black text-slate-800">92%</p>
                                    <p className="text-sm font-bold text-gray-500 mt-2">دقة التنبؤ بنفاد الكميات بناءً على السلوك التاريخي</p>
                                </div>
                                <div className="p-10 bg-purple-50 rounded-[3rem] border-2 border-purple-100">
                                    <p className="text-purple-600 font-black text-xs uppercase tracking-widest mb-4">توصيات AI</p>
                                    <p className="text-xl font-black text-slate-800">توسيع فرع مكة</p>
                                    <p className="text-sm font-bold text-gray-500 mt-2">البيانات تشير إلى فجوة عرض في منطقة مكة المكرمة</p>
                                </div>
                            </div>
                        </div>
                    )}

                    {tab === 'financials' && (
                        <div className="space-y-12 animate-fade-in">
                            <h2 className="text-4xl font-black text-slate-800 uppercase flex items-center gap-4">
                                <ChartBarIcon className="w-10 h-10 text-primary" />
                                {language === 'ar' ? 'التكامل المالي السيادي' : 'Sovereign Financial Integration'}
                            </h2>
                            <div className="bg-white p-10 rounded-[3rem] border-2 border-gray-100 shadow-sm">
                                <div className="space-y-8">
                                    <div className="flex justify-between items-center p-6 bg-slate-50 rounded-2xl border border-gray-100">
                                        <div>
                                            <h4 className="text-xl font-black">{language === 'ar' ? 'ربط الحساب البنكي' : 'Bank Integration'}</h4>
                                            <p className="text-sm font-bold text-gray-400">ANB - SA4730400108095516770029</p>
                                        </div>
                                        <span className="bg-green-100 text-green-600 px-6 py-2 rounded-full font-black text-xs uppercase">Connected</span>
                                    </div>
                                    <div className="flex justify-between items-center p-6 bg-slate-50 rounded-2xl border border-gray-100">
                                        <div>
                                            <h4 className="text-xl font-black">{language === 'ar' ? 'نظام الفوترة الإلكترونية' : 'E-Invoicing'}</h4>
                                            <p className="text-sm font-bold text-gray-400">ZATCA Phase 2 Integration Active</p>
                                        </div>
                                        <span className="bg-green-100 text-green-600 px-6 py-2 rounded-full font-black text-xs uppercase">Active</span>
                                    </div>
                                    <div className="flex justify-between items-center p-6 bg-slate-50 rounded-2xl border border-gray-100">
                                        <div>
                                            <h4 className="text-xl font-black">{language === 'ar' ? 'بوابة الدفع' : 'Payment Gateway'}</h4>
                                            <p className="text-sm font-bold text-gray-400">Stripe / STC Pay Production Ready</p>
                                        </div>
                                        <span className="bg-orange-100 text-orange-600 px-6 py-2 rounded-full font-black text-xs uppercase">Pending</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </main>
            </div>

            {/* Order Details Modal */}
            {isOrderModalOpen && selectedOrder && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-xl z-[100] flex items-center justify-center p-4 md:p-10 overflow-y-auto">
                    <div className="bg-white w-full max-w-4xl rounded-[3rem] overflow-hidden shadow-2xl animate-scale-in">
                        <div className="p-8 md:p-12 border-b-2 border-gray-50 flex justify-between items-center bg-slate-50">
                            <div>
                                <h3 className="text-3xl font-black text-primary uppercase tracking-tighter">Order Details #{selectedOrder.id.slice(-6)}</h3>
                                <p className="text-gray-400 font-bold mt-1">{new Date(selectedOrder.createdAt).toLocaleString('ar-SA')}</p>
                            </div>
                            <button 
                                onClick={() => setIsOrderModalOpen(false)}
                                className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-lg hover:bg-red-500 hover:text-white transition-all group"
                            >
                                <XIcon className="w-6 h-6 group-hover:rotate-90 transition-transform" />
                            </button>
                        </div>
                        
                        <div className="p-8 md:p-12 space-y-10">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                                <div className="space-y-4">
                                    <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest">Customer Information</h4>
                                    <div className="bg-slate-50 p-6 rounded-2xl border border-gray-100">
                                        <p className="text-xl font-black text-slate-800">{selectedOrder.customerName}</p>
                                        <p className="text-sm font-bold text-gray-400 mt-1">ID: {selectedOrder.customerId}</p>
                                        <p className="text-sm font-bold text-primary mt-2">Payment: {selectedOrder.paymentMethod}</p>
                                    </div>
                                </div>
                                <div className="space-y-4">
                                    <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest">Order Status</h4>
                                    <div className="bg-slate-50 p-6 rounded-2xl border border-gray-100 flex items-center justify-between">
                                        <span className={`px-6 py-2 rounded-full font-black text-xs uppercase ${
                                            selectedOrder.status === 'delivered' ? 'bg-green-100 text-green-600' :
                                            selectedOrder.status === 'cancelled' ? 'bg-red-100 text-red-600' :
                                            'bg-blue-100 text-blue-600'
                                        }`}>
                                            {selectedOrder.status}
                                        </span>
                                        <p className="text-sm font-bold text-gray-400">Branch: {branches.find(b => b.id === selectedOrder.branchId)?.name_ar || 'Not Assigned'}</p>
                                    </div>
                                </div>
                            </div>

                            <div className="space-y-6">
                                <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest">Order Items</h4>
                                <div className="bg-white border-2 border-gray-100 rounded-[2rem] overflow-hidden">
                                    <table className="w-full text-right">
                                        <thead className="bg-slate-50 border-b border-gray-100">
                                            <tr>
                                                <th className="p-5 font-black text-primary text-xs uppercase">المنتج</th>
                                                <th className="p-5 font-black text-primary text-xs uppercase text-center">الكمية</th>
                                                <th className="p-5 font-black text-primary text-xs uppercase">السعر</th>
                                                <th className="p-5 font-black text-primary text-xs uppercase">الإجمالي</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-gray-50">
                                            {selectedOrder.items.map((item, idx) => (
                                                <tr key={idx} className="hover:bg-slate-50 transition-all">
                                                    <td className="p-5">
                                                        <div className="flex items-center gap-4">
                                                            <img src={item.image} alt={item.name_ar} className="w-12 h-12 rounded-xl object-cover shadow-sm" />
                                                            <div>
                                                                <p className="font-black text-slate-800">{item.name_ar}</p>
                                                                <p className="text-[10px] font-bold text-gray-400">{item.unit_ar}</p>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td className="p-5 text-center font-black text-slate-600">x{item.quantity}</td>
                                                    <td className="p-5 font-bold text-slate-600">{item.price} ر.س</td>
                                                    <td className="p-5 font-black text-secondary">{(item.price * item.quantity).toFixed(2)} ر.س</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                        <tfoot className="bg-slate-50 border-t-2 border-gray-100">
                                            <tr>
                                                <td colSpan={3} className="p-6 text-left font-black text-slate-400 uppercase tracking-widest">Total Amount</td>
                                                <td className="p-6 font-black text-3xl text-secondary">{selectedOrder.total} ر.س</td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                        
                        <div className="p-8 md:p-12 bg-slate-50 border-t-2 border-gray-100 flex justify-end gap-4">
                            <button 
                                onClick={() => setIsOrderModalOpen(false)}
                                className="px-10 py-4 bg-white border-2 border-gray-200 rounded-2xl font-black text-slate-400 hover:bg-gray-100 transition-all"
                            >
                                Close
                            </button>
                            <button 
                                onClick={() => {
                                    window.print();
                                }}
                                className="px-10 py-4 bg-primary text-white rounded-2xl font-black shadow-xl hover:bg-secondary transition-all"
                            >
                                Print Invoice
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
