
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, Send, MessageSquare, Clock, Globe, ShieldCheck } from 'lucide-react';
import { useI18n } from './lib/contexts/I18nContext';
import { COMPANY_INFO, SOCIAL_LINKS } from './constants';
import { useToast } from './ToastContext';

export const ContactPage: React.FC = () => {
    const { t, language } = useI18n();
    const { addToast } = useToast();
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        // Simulate API call
        setTimeout(() => {
            setIsSubmitting(false);
            addToast(
                language === 'ar' ? 'تم إرسال رسالتك بنجاح. سنتواصل معك قريباً.' : 'Your message has been sent successfully. We will contact you soon.',
                'success'
            );
            (e.target as HTMLFormElement).reset();
        }, 1500);
    };

    const contactItems = [
        {
            icon: <Phone className="w-6 h-6" />,
            title: t('contact.callUs'),
            value: COMPANY_INFO.phone,
            link: `tel:${COMPANY_INFO.phone}`,
            color: 'text-emerald-600'
        },
        {
            icon: <MessageSquare className="w-6 h-6" />,
            title: t('contact.whatsapp'),
            value: COMPANY_INFO.whatsapp,
            link: `https://wa.me/${COMPANY_INFO.whatsapp}`,
            color: 'text-green-500'
        },
        {
            icon: <Mail className="w-6 h-6" />,
            title: t('contact.email'),
            value: COMPANY_INFO.email,
            link: `mailto:${COMPANY_INFO.email}`,
            color: 'text-blue-600'
        },
        {
            icon: <MapPin className="w-6 h-6" />,
            title: t('contact.location'),
            value: COMPANY_INFO.address,
            link: COMPANY_INFO.map_url,
            color: 'text-red-500'
        }
    ];

    return (
        <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="min-h-screen bg-stone-50 pt-24 pb-12 px-4 sm:px-6 lg:px-8"
        >
            <div className="max-w-7xl mx-auto">
                {/* Header Section */}
                <div className="text-center mb-16">
                    <motion.h1 
                        initial={{ scale: 0.9 }}
                        animate={{ scale: 1 }}
                        className="text-4xl md:text-6xl font-bold text-stone-900 mb-4 tracking-tight"
                    >
                        {t('contact.title')}
                    </motion.h1>
                    <p className="text-stone-600 text-lg max-w-2xl mx-auto">
                        {t('contact.subtitle')}
                    </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Contact Info Cards */}
                    <div className="lg:col-span-1 space-y-6">
                        {contactItems.map((item, index) => (
                            <motion.a
                                key={index}
                                href={item.link}
                                target="_blank"
                                rel="noopener noreferrer"
                                whileHover={{ x: language === 'ar' ? -10 : 10 }}
                                className="flex items-center p-6 bg-white rounded-2xl shadow-sm border border-stone-100 hover:shadow-md transition-all"
                            >
                                <div className={`p-4 rounded-xl bg-stone-50 ${item.color} mr-4 rtl:ml-4 rtl:mr-0`}>
                                    {item.icon}
                                </div>
                                <div>
                                    <h3 className="text-sm font-semibold text-stone-500 uppercase tracking-wider">
                                        {item.title}
                                    </h3>
                                    <p className="text-lg font-medium text-stone-900 break-all">
                                        {item.value}
                                    </p>
                                </div>
                            </motion.a>
                        ))}

                        {/* Business Hours */}
                        <div className="p-6 bg-emerald-900 text-white rounded-2xl shadow-lg">
                            <div className="flex items-center mb-4">
                                <Clock className="w-6 h-6 mr-2 rtl:ml-2 rtl:mr-0" />
                                <h3 className="text-xl font-bold">
                                    {t('contact.businessHours')}
                                </h3>
                            </div>
                            <div className="space-y-2 opacity-90">
                                <div className="flex justify-between">
                                    <span>{t('contact.satThu')}</span>
                                    <span>08:00 AM - 10:00 PM</span>
                                </div>
                                <div className="flex justify-between">
                                    <span>{t('contact.friday')}</span>
                                    <span>04:00 PM - 10:00 PM</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Contact Form */}
                    <div className="lg:col-span-2">
                        <div className="bg-white rounded-3xl shadow-sm border border-stone-100 p-8 md:p-12">
                            <h2 className="text-2xl font-bold text-stone-900 mb-8">
                                {t('contact.sendMessage')}
                            </h2>
                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-2">
                                        <label className="text-sm font-medium text-stone-700">
                                            {t('contact.fullName')}
                                        </label>
                                        <input 
                                            required
                                            type="text" 
                                            className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all"
                                            placeholder={t('contact.placeholders.name')}
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-sm font-medium text-stone-700">
                                            {t('contact.phone')}
                                        </label>
                                        <input 
                                            required
                                            type="tel" 
                                            className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all"
                                            placeholder="05xxxxxxxx"
                                        />
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium text-stone-700">
                                        {t('contact.subject')}
                                    </label>
                                    <select className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all">
                                        <option>{t('contact.subjects.general')}</option>
                                        <option>{t('contact.subjects.special')}</option>
                                        <option>{t('contact.subjects.complaint')}</option>
                                        <option>{t('contact.subjects.partnership')}</option>
                                    </select>
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium text-stone-700">
                                        {t('contact.message')}
                                    </label>
                                    <textarea 
                                        required
                                        rows={5}
                                        className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all resize-none"
                                        placeholder={t('contact.placeholders.help')}
                                    ></textarea>
                                </div>
                                <button 
                                    disabled={isSubmitting}
                                    type="submit"
                                    className="w-full md:w-auto px-12 py-4 bg-stone-900 text-white font-bold rounded-xl hover:bg-stone-800 transition-all flex items-center justify-center space-x-2 rtl:space-x-reverse disabled:opacity-50"
                                >
                                    {isSubmitting ? (
                                        <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                    ) : (
                                        <>
                                            <span>{t('contact.submit')}</span>
                                            <Send className="w-5 h-5" />
                                        </>
                                    )}
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                {/* Map Section */}
                <div className="mt-16 rounded-3xl overflow-hidden shadow-lg border border-stone-200 h-[400px] relative">
                    <iframe 
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3710.463242694119!2d39.2238466!3d21.5678466!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3d1e7c5e5e5e5%3A0xed98cfhgw5ujyxjx7!2z2LTYp9ix2Lkg2KfZhNmF2YbYp9ix!5e0!3m2!1sar!2ssa!4v1710400000000!5m2!1sar!2ssa" 
                        width="100%" 
                        height="100%" 
                        style={{ border: 0 }} 
                        allowFullScreen 
                        loading="lazy" 
                        referrerPolicy="no-referrer-when-downgrade"
                    ></iframe>
                    <div className="absolute bottom-6 left-6 right-6 md:left-auto md:w-80 bg-white/90 backdrop-blur-md p-6 rounded-2xl shadow-xl border border-white/20">
                        <div className="flex items-center mb-2 text-emerald-700">
                            <ShieldCheck className="w-5 h-5 mr-2 rtl:ml-2 rtl:mr-0" />
                            <span className="text-xs font-bold uppercase tracking-widest">{language === 'ar' ? 'موقعنا المعتمد' : 'Verified Location'}</span>
                        </div>
                        <h4 className="font-bold text-stone-900 mb-1">{COMPANY_INFO.name}</h4>
                        <p className="text-sm text-stone-600">{COMPANY_INFO.address}</p>
                    </div>
                </div>
            </div>
        </motion.div>
    );
};
