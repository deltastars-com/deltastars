import React from 'react';
// import { motion } from 'framer-motion';
import { Product, Page, CategoryConfig, Promotion, CategoryKey, HomeSection } from '../types';
import { useI18n } from './lib/contexts/I18nContext';
import { COMPANY_INFO, CATEGORY_ICONS } from './constants';
import { 
    SparklesIcon, QualityIcon, TelegramIcon, WhatsappIcon, ShieldCheckIcon, GlobeAltIcon 
} from './lib/contexts/Icons';
import { SOCIAL_LINKS, INSTITUTIONAL_VERIFICATION } from './constants';

export function Home({ setPage, sections, categories = [], products = [], promotions = [], addToCart }: {
    setPage: (p: Page, productId?: number, category?: string) => void;
    addToCart: (p: Product) => void;
    products: Product[];
    promotions: Promotion[];
    categories?: CategoryConfig[];
    sections: HomeSection[];
}) {
    const { t, language } = useI18n();

    const activeCategories = (categories.length > 0 ? categories.filter(c => c.isVisible) : [
        { key: 'vegetables', label_ar: 'خضروات', label_en: 'Vegetables' },
        { key: 'fruits', label_ar: 'فواكة', label_en: 'Fruits' },
        { key: 'herbs', label_ar: 'ورقيات', label_en: 'Herbs & Greens' },
        { key: 'dates', label_ar: 'تمور', label_en: 'Dates' },
        { key: 'qassim', label_ar: 'منتجات القصيم', label_en: 'Qassim Products' },
        { key: 'seasonal', label_ar: 'منتجات موسمية', label_en: 'Seasonal Products' },
        { key: 'packages', label_ar: 'مغلفات', label_en: 'Packages' },
        { key: 'nuts', label_ar: 'مكسرات', label_en: 'Nuts' },
        { key: 'flowers', label_ar: 'الورود والهدايا', label_en: 'Flowers & Gifts' }
    ]).map(c => ({ 
        key: c.key as CategoryKey, 
        label: language === 'ar' ? (c as any).label_ar : (c as any).label_en 
    }));

    const handleCategoryClick = (key: CategoryKey) => {
        setPage('products', undefined, key);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const renderHero = () => (
        <section 
            key="hero" 
            className="relative h-[85vh] md:h-[90vh] flex items-center justify-center bg-white overflow-hidden"
        >
            <div className="absolute inset-0 z-0">
                <img 
                    src={COMPANY_INFO.wide_banner_url} 
                    className="w-full h-full object-cover scale-105 saturate-[1.1] transition-transform duration-[30s] animate-slow-pan" 
                    alt={`${COMPANY_INFO.name} Strategic Supply`} 
                />
                <div className="absolute inset-0 bg-gradient-to-l from-white/20 via-transparent to-white/95"></div>
                <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-transparent"></div>
            </div>

            <div className="w-full max-w-7xl px-4 md:px-6 z-20">
                <div 
                    className="bg-white/40 backdrop-blur-3xl border border-white/60 p-12 md:p-24 rounded-[5rem] md:rounded-[6.5rem] shadow-sovereign max-w-6xl" 
                    dir={language === 'ar' ? 'rtl' : 'ltr'}
                >
                    <div 
                        className="bg-primary text-white px-8 py-3 rounded-full inline-flex items-center gap-4 font-black text-[11px] mb-10 uppercase tracking-[0.4em] shadow-xl"
                    >
                         <SparklesIcon className="w-5 h-5 text-secondary animate-pulse" />
                         {language === 'ar' ? 'الجودة المطلقة من المزرعة للمائدة' : 'ABSOLUTE QUALITY FROM FARM TO TABLE'}
                    </div>
                    
                    <h2 
                        className="text-7xl md:text-9xl lg:text-[11rem] font-black text-primary mb-6 leading-[0.8] tracking-[-0.04em] uppercase drop-shadow-md"
                    >
                         {t('home.hero.headline')}
                    </h2>
                    
                    <p 
                        className="text-2xl md:text-4xl lg:text-5xl font-medium mb-16 max-w-5xl leading-tight text-primary/80 italic tracking-tight border-r-4 border-secondary/60 pr-8"
                    >
                        {t('home.hero.description')}
                    </p>
                    
                    <div className="flex flex-wrap gap-8 md:gap-12">
                        <button 
                            onClick={() => setPage('products')} 
                            className="group relative bg-primary text-white px-12 md:px-20 py-6 md:py-10 rounded-[3rem] font-black text-2xl md:text-5xl transition-all shadow-4xl border-b-[15px] border-primary-dark active:translate-y-2 active:border-b-4"
                        >
                            <span className="flex items-center gap-6 uppercase tracking-widest">
                                🛒 {t('home.hero.button')}
                            </span>
                        </button>
                        <button 
                            onClick={() => setPage('vipLogin')} 
                            className="group relative bg-white/90 backdrop-blur-md text-primary px-12 md:px-16 py-6 md:py-10 rounded-[3rem] font-black text-2xl transition-all shadow-xl border-2 border-primary/10 border-b-[15px] border-gray-200 active:translate-y-2 active:border-b-4"
                        >
                            <span className="flex items-center gap-6 uppercase tracking-widest">
                                🔐 {t('home.hero.vipButton')}
                            </span>
                        </button>
                    </div>
                </div>
            </div>
        </section>
    );

    const renderCategories = () => (
        <section key="categories" className="bg-slate-50 py-40 relative z-20 border-y-2 border-gray-100">
            <div className="container mx-auto px-6 text-center">
                <div 
                    className="mb-24"
                >
                    <div className="inline-flex items-center gap-4 bg-primary text-white px-10 py-4 rounded-full font-black text-[12px] uppercase tracking-widest mb-10 shadow-xl">
                        {language === 'ar' ? 'وحدات توريد استراتيجية' : 'Strategic Supply Units'}
                    </div>
                    <h2 className="text-6xl md:text-9xl font-black text-primary mb-10 uppercase tracking-tighter leading-none">
                        {t('home.categories.title')}
                    </h2>
                    <div className="h-2.5 w-64 bg-secondary mx-auto rounded-full mb-12 opacity-80"></div>
                    <p className="text-3xl md:text-4xl font-bold text-gray-400 italic max-w-4xl mx-auto leading-relaxed">{t('home.categories.subtitle')}</p>
                </div>

                <div 
                    className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 md:gap-8 max-w-[1600px] mx-auto px-4"
                >
                    {activeCategories.map((cat, idx) => (
                        <div 
                            key={cat.key} 
                            onClick={() => handleCategoryClick(cat.key)} 
                            className={`group bg-white rounded-[4rem] flex flex-col items-center text-center cursor-pointer transition-all duration-700 border-2 border-gray-100 shadow-xl hover:shadow-sovereign hover:border-secondary relative overflow-hidden ${
                                idx === 0 ? 'md:col-span-2 md:row-span-2 p-16' : 
                                idx === 1 || idx === 4 ? 'md:row-span-2 p-12' : 'p-10'
                            }`}
                        >
                            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-[2.5] transition-transform duration-1000"></div>
                            
                            <div className={`relative mb-8 p-6 rounded-full bg-gray-50 group-hover:bg-primary/5 transition-all duration-700 group-hover:rotate-12 group-hover:scale-110 shadow-inner ${
                                idx === 0 ? 'w-40 h-40' : 'w-24 h-24'
                            }`}>
                                <div className="w-full h-full flex items-center justify-center overflow-hidden">
                                    <img 
                                        src={CATEGORY_ICONS[cat.key as keyof typeof CATEGORY_ICONS]} 
                                        alt={cat.label} 
                                        className="w-full h-full object-contain filter drop-shadow-2xl" 
                                        loading="lazy"
                                    />
                                </div>
                            </div>
                            
                            <h3 className={`font-black text-primary group-hover:text-secondary transition-colors uppercase tracking-tight leading-tight mb-4 flex items-center justify-center ${
                                idx === 0 ? 'text-4xl' : 'text-2xl'
                            }`}>
                                {cat.label}
                            </h3>
                            
                            <p className="text-xs font-bold text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity mb-4">
                                {language === 'ar' ? 'استكشف التوريدات' : 'Explore Supplies'}
                            </p>

                            <div className="w-12 h-1.5 bg-gray-100 group-hover:w-24 group-hover:bg-secondary transition-all rounded-full"></div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );

    const renderPartners = () => (
        <section key="partners" className="bg-white py-48 relative z-20 overflow-hidden border-t-8 border-gray-100">
            <div className="container mx-auto px-6 relative z-10 text-center">
                <div 
                    className="inline-flex items-center gap-6 bg-primary/5 px-16 py-6 rounded-full border border-primary/10 text-primary font-black text-sm mb-20 uppercase tracking-[0.6em] shadow-sm"
                >
                    <QualityIcon className="w-10 h-10 text-secondary" /> {t('home.partners.badge')}
                </div>
                
                <h2 
                    className="text-5xl sm:text-7xl md:text-9xl lg:text-[12rem] font-black text-primary uppercase tracking-tighter leading-none mb-32 drop-shadow-sm"
                >
                    {t('home.partners.title')}
                </h2>
                
                <div 
                    className="bg-white rounded-[7rem] p-12 md:p-32 shadow-sovereign border-x-4 border-b-[40px] border-primary overflow-hidden flex justify-center items-center group relative transition-all duration-700 hover:shadow-[0_100px_150px_rgba(0,0,0,0.25)]"
                >
                    <div className="absolute inset-0 bg-gradient-to-tr from-primary/5 via-transparent to-primary/5 pointer-events-none"></div>
                    <img 
                        src={COMPANY_INFO.partners_url} 
                        alt="Delta Stars Strategic Partners" 
                        className="w-full max-w-[1700px] h-auto object-contain drop-shadow-[0_35px_60px_rgba(0,0,0,0.3)] saturate-[1.2] contrast-[1.1]"
                        loading="lazy"
                    />
                </div>
                
                <div className="mt-24 text-primary/30 font-black text-[11px] uppercase tracking-[0.6em] animate-pulse">
                    Verified Institutional Supplier Network • Delta Sovereign Hub
                </div>
            </div>
        </section>
    );

    const renderCustomers = () => (
        <section key="customers" className="bg-slate-50 py-48 relative z-20 overflow-hidden border-t-8 border-gray-100">
            <div className="container mx-auto px-6 relative z-10 text-center">
                <div 
                    className="inline-flex items-center gap-6 bg-primary/5 px-16 py-6 rounded-full border border-primary/10 text-primary font-black text-sm mb-20 uppercase tracking-[0.6em] shadow-sm"
                >
                    💎 {language === 'ar' ? 'شركاء النجاح' : 'SUCCESS PARTNERS'}
                </div>
                
                <h2 
                    className="text-5xl sm:text-7xl md:text-9xl font-black text-primary uppercase tracking-tighter leading-none mb-32 drop-shadow-sm"
                >
                    {language === 'ar' ? 'عملاؤنا الكرام' : 'OUR VALUED CUSTOMERS'}
                </h2>
                
                <div 
                    className="bg-white rounded-[7rem] p-12 md:p-24 shadow-sovereign border-x-4 border-b-[40px] border-secondary overflow-hidden flex justify-center items-center group relative transition-all duration-700 hover:shadow-[0_100px_150px_rgba(0,0,0,0.25)]"
                >
                    <div className="absolute inset-0 bg-gradient-to-tr from-secondary/5 via-transparent to-secondary/5 pointer-events-none"></div>
                    <img 
                        src="https://drive.google.com/uc?export=view&id=1ncgLWgU7451YY8W9B8-fnSWJho9BrpQN" 
                        alt="Delta Stars Valued Customers" 
                        className="w-full max-w-[1700px] h-auto object-contain drop-shadow-[0_35px_60px_rgba(0,0,0,0.3)]"
                        loading="lazy"
                        referrerPolicy="no-referrer"
                    />
                </div>
            </div>
        </section>
    );

    const renderTrust = () => (
        <section key="trust" className="bg-white py-40 relative z-20 border-t-8 border-gray-100">
            <div className="container mx-auto px-6">
                <div 
                    className="text-center mb-24"
                >
                    <div className="inline-flex items-center gap-4 bg-primary text-white px-10 py-4 rounded-full font-black text-[12px] uppercase tracking-widest mb-10 shadow-xl">
                        <ShieldCheckIcon className="w-6 h-6 text-secondary" /> {language === 'ar' ? 'التراخيص والاعتمادات الرسمية' : 'OFFICIAL LICENSES & ACCREDITATIONS'}
                    </div>
                    <h2 className="text-6xl md:text-9xl font-black text-primary mb-10 uppercase tracking-tighter leading-none">
                        {language === 'ar' ? 'الشفافية المؤسسية' : 'INSTITUTIONAL TRANSPARENCY'}
                    </h2>
                    <div className="h-2.5 w-64 bg-secondary mx-auto rounded-full mb-12 opacity-80"></div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 max-w-7xl mx-auto">
                    {INSTITUTIONAL_VERIFICATION.map((badge, idx) => (
                        <div 
                            key={idx} 
                            className="group bg-slate-50 p-12 rounded-[4rem] border-2 border-transparent hover:border-secondary hover:bg-white hover:shadow-sovereign transition-all duration-700 flex flex-col items-center text-center"
                        >
                            <div className="w-32 h-32 mb-10 bg-white rounded-[2.5rem] p-6 shadow-2xl flex items-center justify-center transition-all duration-500 group-hover:scale-110 group-hover:rotate-6 border border-gray-100">
                                <img src={badge.icon} alt={badge.title_ar} className="w-full h-auto object-contain" />
                            </div>
                            <h4 className="text-secondary font-black text-xs uppercase tracking-[0.4em] mb-4 opacity-80">
                                {language === 'ar' ? badge.title_ar : badge.title_en}
                            </h4>
                            <p className="text-3xl font-black font-mono tracking-tighter text-primary select-all">
                                {badge.number}
                            </p>
                            <div className="mt-8 w-12 h-1 bg-gray-200 group-hover:w-24 group-hover:bg-secondary transition-all rounded-full"></div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );

    const renderChannels = () => (
        <section key="channels" className="bg-slate-950 py-48 relative overflow-hidden">
            <div className="absolute inset-0 z-0 opacity-20">
                <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
                <div className="absolute top-[-20%] right-[-10%] w-[60%] h-[60%] bg-primary blur-[150px] rounded-full"></div>
                <div className="absolute bottom-[-20%] left-[-10%] w-[60%] h-[60%] bg-secondary blur-[150px] rounded-full"></div>
            </div>

            <div className="container mx-auto px-6 relative z-10">
                <div 
                    className="text-center mb-32"
                >
                    <div className="inline-flex items-center gap-4 bg-white/5 border border-white/10 px-10 py-4 rounded-full text-secondary font-black text-xs uppercase tracking-[0.4em] mb-10">
                        <SparklesIcon className="w-6 h-6 animate-pulse" /> {language === 'ar' ? 'قنوات التواصل السيادية' : 'SOVEREIGN COMMUNICATION CHANNELS'}
                    </div>
                    <h2 className="text-6xl md:text-9xl font-black text-white uppercase tracking-tighter leading-none mb-10">
                        {language === 'ar' ? 'لمعرفة كل جديد انظم لقنواتنا' : 'To know all that is new, join our channels'}
                    </h2>
                    <p className="text-3xl font-bold text-white/40 max-w-4xl mx-auto leading-relaxed italic">
                        {language === 'ar' ? 'كن أول من يعلم بأحدث التوريدات الاستراتيجية والعروض الحصرية عبر قنواتنا الرسمية' : 'Be the first to know about the latest strategic supplies and exclusive offers via our official channels'}
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-7xl mx-auto">
                    <a 
                        href={SOCIAL_LINKS.telegram_channel} 
                        target="_blank" rel="noreferrer"
                        className="group relative bg-white/5 backdrop-blur-3xl border border-white/10 p-16 rounded-[5rem] overflow-hidden transition-all duration-700 hover:bg-white/10 hover:border-secondary/30 shadow-2xl"
                    >
                        <div className="absolute top-0 right-0 w-64 h-64 bg-[#0088cc]/10 blur-3xl rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-150 transition-transform duration-1000"></div>
                        <div className="relative z-10 flex flex-col items-center text-center">
                            <div className="w-32 h-32 bg-[#0088cc] rounded-[2.5rem] flex items-center justify-center mb-10 shadow-2xl group-hover:rotate-12 transition-transform duration-700">
                                <TelegramIcon className="w-16 h-16 text-white" />
                            </div>
                            <h3 className="text-4xl font-black text-white mb-6 uppercase tracking-tight">Telegram Channel</h3>
                            <p className="text-white/50 font-bold text-xl mb-12 leading-relaxed">
                                {language === 'ar' ? 'تحديثات لحظية للأسعار والمنتجات الجديدة' : 'Real-time updates on prices and new products'}
                            </p>
                            <div className="bg-white/10 px-12 py-5 rounded-full text-white font-black text-sm uppercase tracking-widest group-hover:bg-[#0088cc] transition-colors">
                                {language === 'ar' ? 'انظم الآن' : 'JOIN NOW'}
                            </div>
                        </div>
                    </a>

                    <a 
                        href={SOCIAL_LINKS.whatsapp_community} 
                        target="_blank" rel="noreferrer"
                        className="group relative bg-white/5 backdrop-blur-3xl border border-white/10 p-16 rounded-[5rem] overflow-hidden transition-all duration-700 hover:bg-white/10 hover:border-secondary/30 shadow-2xl"
                    >
                        <div className="absolute top-0 right-0 w-64 h-64 bg-[#25D366]/10 blur-3xl rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-150 transition-transform duration-1000"></div>
                        <div className="relative z-10 flex flex-col items-center text-center">
                            <div className="w-32 h-32 bg-[#25D366] rounded-[2.5rem] flex items-center justify-center mb-10 shadow-2xl group-hover:-rotate-12 transition-transform duration-700">
                                <WhatsappIcon className="w-16 h-16 text-white" />
                            </div>
                            <h3 className="text-4xl font-black text-white mb-6 uppercase tracking-tight">WhatsApp Community</h3>
                            <p className="text-white/50 font-bold text-xl mb-12 leading-relaxed">
                                {language === 'ar' ? 'تواصل مباشر ودعم فني على مدار الساعة' : 'Direct communication and 24/7 technical support'}
                            </p>
                            <div className="bg-white/10 px-12 py-5 rounded-full text-white font-black text-sm uppercase tracking-widest group-hover:bg-[#25D366] transition-colors">
                                {language === 'ar' ? 'انظم الآن' : 'JOIN NOW'}
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </section>
    );

    const renderFeaturedProducts = () => {
        const featured = products.filter(p => [236, 233, 234, 235, 237, 225, 226, 227].includes(p.id));
        
        return (
            <section key="featured" className="bg-white py-40 relative z-20 border-t-8 border-gray-100">
                <div className="container mx-auto px-6">
                    <div className="text-center mb-24">
                        <div className="inline-flex items-center gap-4 bg-primary text-white px-10 py-4 rounded-full font-black text-[12px] uppercase tracking-widest mb-10 shadow-xl">
                            <SparklesIcon className="w-6 h-6 text-secondary" /> {language === 'ar' ? 'منتجات مختارة بعناية' : 'CAREFULLY SELECTED PRODUCTS'}
                        </div>
                        <h2 className="text-6xl md:text-9xl font-black text-primary mb-10 uppercase tracking-tighter leading-none">
                            {language === 'ar' ? 'أبرز التوريدات' : 'FEATURED SUPPLIES'}
                        </h2>
                        <div className="h-2.5 w-64 bg-secondary mx-auto rounded-full mb-12 opacity-80"></div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
                        {featured.map((product) => (
                            <div 
                                key={product.id}
                                onClick={() => setPage('productDetail', product.id)}
                                className="group relative bg-slate-50 rounded-[4rem] overflow-hidden cursor-pointer transition-all duration-700 hover:shadow-sovereign border-2 border-transparent hover:border-secondary"
                            >
                                <div className="aspect-square overflow-hidden relative">
                                    <img 
                                        src={product.image} 
                                        alt={language === 'ar' ? product.name_ar : product.name_en}
                                        className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
                                        referrerPolicy="no-referrer"
                                    />
                                    <div className="absolute inset-0 bg-gradient-to-t from-primary/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 flex items-end p-10">
                                        <span className="text-white font-black text-xl uppercase tracking-widest">
                                            {language === 'ar' ? 'عرض التفاصيل' : 'View Details'}
                                        </span>
                                    </div>
                                </div>
                                <div className="p-10">
                                    <h3 className="text-2xl font-black text-primary mb-2 uppercase tracking-tight">
                                        {language === 'ar' ? product.name_ar : product.name_en}
                                    </h3>
                                    <div className="flex items-center justify-between">
                                        <p className="text-secondary font-black text-3xl">
                                            {product.price} <span className="text-sm opacity-60 uppercase">{language === 'ar' ? 'ريال' : 'SAR'}</span>
                                        </p>
                                        <button 
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                addToCart(product);
                                            }}
                                            className="bg-secondary text-white p-4 rounded-2xl hover:bg-secondary-dark transition-all active:scale-90 shadow-lg"
                                        >
                                            🛒
                                        </button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                    
                    <div className="mt-24 text-center">
                        <button 
                            onClick={() => setPage('products')}
                            className="bg-primary text-white px-16 py-8 rounded-full font-black text-2xl uppercase tracking-widest hover:bg-primary-dark transition-all shadow-xl hover:shadow-2xl active:scale-95"
                        >
                            {language === 'ar' ? 'عرض كافة المنتجات' : 'VIEW ALL PRODUCTS'}
                        </button>
                    </div>
                </div>
            </section>
        );
    };

    const sortedSections = [...sections].sort((a, b) => a.order - b.order);

    return (
        <div className="space-y-0 bg-white overflow-x-hidden selection:bg-secondary selection:text-white pt-24 md:pt-32">
            {sortedSections.map(section => {
                if (!section.isVisible) return null;
                switch (section.type) {
                    case 'hero': return renderHero();
                    case 'featured_products': return renderFeaturedProducts();
                    case 'categories': return renderCategories();
                    case 'partners': return renderPartners();
                    case 'customers': return renderCustomers();
                    case 'trust': return renderTrust();
                    case 'channels': return renderChannels();
                    default: return null;
                }
            })}

            <style>{`
                @keyframes slow-pan {
                    0% { transform: scale(1.05) translateX(0); }
                    50% { transform: scale(1.18) translateX(-3%); }
                    100% { transform: scale(1.05) translateX(0); }
                }
                .animate-slow-pan {
                    animation: slow-pan 35s infinite alternate ease-in-out;
                }
            `}</style>
        </div>
    );
}

export default Home;
