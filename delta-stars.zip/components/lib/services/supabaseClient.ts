
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'placeholder';

// Create client with placeholders if real keys are missing to prevent startup crash
export const supabase = createClient(supabaseUrl, supabaseAnonKey);
