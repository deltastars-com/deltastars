
import React, { createContext, useContext, useEffect, useState } from 'react';
import { auth, db, onAuthStateChanged, onSnapshot, collection, query, orderBy, where, handleFirestoreError, OperationType, FirebaseUser } from '../../../firebase';
import { User, Product, CategoryConfig, ProductUnit, HomeSection, Order, Branch } from '../../../types';

interface FirebaseContextType {
  user: User | null;
  firebaseUser: FirebaseUser | null;
  products: Product[];
  categories: CategoryConfig[];
  units: ProductUnit[];
  homeSections: HomeSection[];
  orders: Order[];
  branches: Branch[];
  loading: boolean;
  error: string | null;
  db: any;
}

const FirebaseContext = createContext<FirebaseContextType | undefined>(undefined);

export const FirebaseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<CategoryConfig[]>([]);
  const [units, setUnits] = useState<ProductUnit[]>([]);
  const [homeSections, setHomeSections] = useState<HomeSection[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (fbUser) {
        // Fetch user role and data from Firestore
        const userDocRef = `users/${fbUser.uid}`;
        onSnapshot(collection(db, 'users'), (snapshot) => {
           const userData = snapshot.docs.find(d => d.id === fbUser.uid)?.data() as User;
           if (userData) {
             setUser(userData);
           } else {
             // Default role for new users
             setUser({ type: 'client', email: fbUser.email || '', name: fbUser.displayName || '' });
           }
        }, (err) => handleFirestoreError(err, OperationType.GET, 'users'));
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    // Real-time sync for products
    const unsubscribeProducts = onSnapshot(collection(db, 'products'), (snapshot) => {
      setProducts(snapshot.docs.map(doc => ({ ...doc.data(), id: Number(doc.id) } as Product)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'products'));

    // Real-time sync for categories
    const unsubscribeCategories = onSnapshot(query(collection(db, 'categories'), orderBy('order')), (snapshot) => {
      setCategories(snapshot.docs.map(doc => doc.data() as CategoryConfig));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'categories'));

    // Real-time sync for units
    const unsubscribeUnits = onSnapshot(collection(db, 'units'), (snapshot) => {
      setUnits(snapshot.docs.map(doc => doc.data() as ProductUnit));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'units'));

    // Real-time sync for home sections
    const unsubscribeSections = onSnapshot(query(collection(db, 'homeSections'), orderBy('order')), (snapshot) => {
      setHomeSections(snapshot.docs.map(doc => doc.data() as HomeSection));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'homeSections'));

    // Real-time sync for branches
    const unsubscribeBranches = onSnapshot(collection(db, 'branches'), (snapshot) => {
      setBranches(snapshot.docs.map(doc => doc.data() as Branch));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'branches'));

    return () => {
      unsubscribeAuth();
      unsubscribeProducts();
      unsubscribeCategories();
      unsubscribeUnits();
      unsubscribeSections();
      unsubscribeBranches();
    };
  }, []);

  // Sync orders if user is admin or has orders
  useEffect(() => {
    if (!user) {
      setOrders([]);
      return;
    }

    let q;
    if (['admin', 'developer', 'gm', 'ops'].includes(user.type)) {
      q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    } else {
      q = query(collection(db, 'orders'), where('customerId', '==', firebaseUser?.uid), orderBy('createdAt', 'desc'));
    }

    const unsubscribeOrders = onSnapshot(q, (snapshot) => {
      setOrders(snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Order)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'orders'));

    return () => unsubscribeOrders();
  }, [user, firebaseUser]);

  return (
    <FirebaseContext.Provider value={{ user, firebaseUser, products, categories, units, homeSections, orders, branches, loading, error, db }}>
      {children}
    </FirebaseContext.Provider>
  );
};

export const useFirebase = () => {
  const context = useContext(FirebaseContext);
  if (context === undefined) {
    throw new Error('useFirebase must be used within a FirebaseProvider');
  }
  return context;
};
