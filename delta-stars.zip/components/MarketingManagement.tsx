import React, { useState } from 'react';

export default function MarketingManagement() {
  const [promotions, setPromotions] = useState([
    { id: 1, title: 'عرض رمضان المبارك', discount: '20%', status: 'نشط', type: 'خصم مباشر' },
    { id: 2, title: 'باقة الفواكه الموسمية', discount: '15%', status: 'مجدول', type: 'باقة توفير' },
    { id: 3, title: 'عرض نهاية الأسبوع', discount: '10%', status: 'منتهي', type: 'عرض محدود' },
  ]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-black text-[#1a3a1a]">التسويق والعروض الترويجية</h3>
        <button className="bg-[#FF922B] text-white px-6 py-2 rounded-xl font-bold hover:scale-105 transition-all shadow-lg">
          + إنشاء عرض جديد
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {promotions.map(promo => (
          <div key={promo.id} className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-gray-100 hover:shadow-xl transition-all group">
            <div className="flex justify-between items-start mb-4">
              <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                promo.status === 'نشط' ? 'bg-emerald-50 text-emerald-600' : 
                promo.status === 'مجدول' ? 'bg-blue-50 text-blue-600' : 'bg-gray-50 text-gray-400'
              }`}>
                {promo.status}
              </div>
              <span className="text-2xl font-black text-[#FF922B]">{promo.discount}</span>
            </div>
            <h4 className="text-lg font-black text-[#1a3a1a] mb-2">{promo.title}</h4>
            <p className="text-xs text-gray-400 font-bold mb-6">{promo.type}</p>
            <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <button className="flex-1 py-2 bg-gray-50 text-primary rounded-xl font-bold text-xs">تعديل</button>
              <button className="flex-1 py-2 bg-red-50 text-red-500 rounded-xl font-bold text-xs">إيقاف</button>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-[#1a3a1a] p-10 rounded-[3rem] text-white relative overflow-hidden">
        <div className="relative z-10 max-w-lg">
          <h4 className="text-3xl font-black mb-4 tracking-tighter">تحليلات التسويق الذكية</h4>
          <p className="text-white/70 font-bold mb-8 leading-relaxed">
            استخدم تقنيات الذكاء الاصطناعي لتوقع سلوك العملاء وتحسين العروض بناءً على البيانات التاريخية للمبيعات.
          </p>
          <button className="bg-[#FF922B] text-white px-8 py-3 rounded-2xl font-black shadow-2xl hover:scale-105 transition-all">
            تفعيل التوقع الذكي
          </button>
        </div>
        <div className="absolute top-0 end-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
      </div>
    </div>
  );
}
