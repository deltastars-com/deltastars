import React, { useState } from 'react';

export default function AccountingManagement() {
  const [invoices, setInvoices] = useState([
    { id: 'INV-2024-001', customer: 'شركة نجوم دلتا', amount: '15,400 ر.س', status: 'مدفوع', date: '2024-03-24' },
    { id: 'INV-2024-002', customer: 'مطعم السفير', amount: '4,200 ر.س', status: 'معلق', date: '2024-03-24' },
    { id: 'INV-2024-003', customer: 'فندق هيلتون', amount: '28,900 ر.س', status: 'متأخر', date: '2024-03-20' },
  ]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-black text-[#1a3a1a]">المحاسبة والمالية</h3>
        <div className="flex gap-2">
          <button className="bg-white text-[#1a3a1a] px-4 py-2 rounded-xl font-bold border border-gray-100 shadow-sm">
            تصدير Excel
          </button>
          <button className="bg-[#FF922B] text-white px-6 py-2 rounded-xl font-bold hover:scale-105 transition-all shadow-lg">
            + فاتورة جديدة
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100">
          <p className="text-xs text-gray-400 font-bold mb-1">إجمالي المبيعات</p>
          <p className="text-2xl font-black text-[#1a3a1a]">145,000 ر.س</p>
        </div>
        <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100">
          <p className="text-xs text-gray-400 font-bold mb-1">المبالغ المحصلة</p>
          <p className="text-2xl font-black text-emerald-500">112,000 ر.س</p>
        </div>
        <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100">
          <p className="text-xs text-gray-400 font-bold mb-1">مبالغ معلقة</p>
          <p className="text-2xl font-black text-[#FF922B]">23,000 ر.س</p>
        </div>
        <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100">
          <p className="text-xs text-gray-400 font-bold mb-1">مبالغ متأخرة</p>
          <p className="text-2xl font-black text-red-500">10,000 ر.س</p>
        </div>
      </div>

      <div className="bg-white rounded-[3rem] shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-8 border-b border-gray-50 flex justify-between items-center">
          <h4 className="text-lg font-black text-[#1a3a1a]">الفواتير الأخيرة</h4>
          <div className="flex gap-4">
            <span className="text-xs font-black text-gray-400 uppercase tracking-widest">فرز حسب: التاريخ</span>
          </div>
        </div>
        <div className="divide-y divide-gray-50">
          {invoices.map(invoice => (
            <div key={invoice.id} className="p-6 hover:bg-gray-50/50 transition-all flex items-center justify-between group">
              <div className="flex items-center gap-6">
                <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center text-[#1a3a1a] font-black text-xs">
                  INV
                </div>
                <div>
                  <h5 className="text-sm font-black text-[#1a3a1a] mb-1">{invoice.customer}</h5>
                  <p className="text-xs text-gray-400 font-bold">{invoice.id} • {invoice.date}</p>
                </div>
              </div>
              <div className="flex items-center gap-12">
                <div className="text-left">
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">المبلغ</p>
                  <p className="text-sm font-black text-[#1a3a1a]">{invoice.amount}</p>
                </div>
                <div className="text-left">
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">الحالة</p>
                  <span className={`px-3 py-1 rounded-full text-[10px] font-black ${
                    invoice.status === 'مدفوع' ? 'bg-emerald-50 text-emerald-600' : 
                    invoice.status === 'معلق' ? 'bg-blue-50 text-blue-600' : 'bg-red-50 text-red-500'
                  }`}>
                    {invoice.status}
                  </span>
                </div>
                <button className="p-3 bg-gray-50 text-[#1a3a1a] rounded-2xl opacity-0 group-hover:opacity-100 transition-all hover:bg-[#1a3a1a] hover:text-white">
                  تفاصيل
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
