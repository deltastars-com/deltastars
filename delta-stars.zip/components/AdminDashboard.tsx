import React, { useState, useEffect } from 'react';
import { supabase } from './lib/supabaseClient';
import DashboardStats from './DashboardStats';
import FleetRadar from './FleetRadar';
import OrderManagement from './OrderManagement';
import ProductManagement from './ProductManagement';
import MarketingManagement from './MarketingManagement';
import QualityManagement from './QualityManagement';
import ComplaintsManagement from './ComplaintsManagement';
import AccountingManagement from './AccountingManagement';
import DeveloperManagement from './DeveloperManagement';

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const [adminName, setAdminName] = useState('مدير النظام');
  const [userRole, setUserRole] = useState<string | null>(null);

  // التأكد من صلاحيات الدخول
  useEffect(() => {
    const checkAdmin = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      
      // If no supabase user, we might be using the App.tsx hardcoded login
      // For now, let's try to get role from profiles if user exists
      if (user) {
        const { data } = await supabase.from('profiles').select('role, company_name').eq('id', user?.id).single();
        if (data) {
          setAdminName(data.company_name || 'مدير النظام');
          setUserRole(data.role);
        }
      } else {
        // Fallback for demo/dev if supabase is not fully set up
        // We'll assume the user is authorized if they reached this page via App.tsx routing
        setUserRole('admin'); 
      }
    };
    checkAdmin();
  }, []);

  const menuItems = [
    { id: 'overview', label: 'نظرة عامة', icon: 'M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z' },
    { id: 'orders', label: 'إدارة الطلبات', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01' },
    { id: 'fleet', label: 'رادار الأسطول', icon: 'M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7' },
    { id: 'products', label: 'المنتجات والمخزون', icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' },
    { id: 'marketing', label: 'التسويق والعروض', icon: 'M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z' },
    { id: 'quality', label: 'إدارة الجودة', icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z' },
    { id: 'complaints', label: 'الشكاوى والملاحظات', icon: 'M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z' },
    { id: 'accounting', label: 'المحاسبة والمالية', icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M12 16V15m0 1v-8' },
  ];

  // Only show developer tab if role is developer or admin
  if (userRole === 'admin' || userRole === 'developer') {
    menuItems.push({ id: 'developer', label: 'قسم المطور', icon: 'M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4' });
  }

  return (
    <div className="flex h-screen bg-slate-50 text-slate-800 font-main" dir="rtl">
      
      {/* القائمة الجانبية (Sidebar) */}
      <aside className="w-72 bg-[#1a3a1a] text-white flex flex-col shadow-2xl z-20">
        <div className="p-6 text-center border-b border-white/10">
          <h1 className="text-2xl font-black text-[#FF922B] tracking-wider">نجوم دلتا</h1>
          <p className="text-xs text-white/50 mt-1 uppercase tracking-widest">Sovereign Command</p>
        </div>
        
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto custom-scrollbar">
          {menuItems.map((item) => (
            <button 
              key={item.id}
              onClick={() => setActiveTab(item.id)} 
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === item.id ? 'bg-[#FF922B] text-white font-bold shadow-lg scale-[1.02]' : 'hover:bg-white/10 text-white/70'}`}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={item.icon}></path>
              </svg>
              {item.label}
            </button>
          ))}
        </nav>
        
        <div className="p-4 border-t border-white/10 bg-black/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#FF922B] flex items-center justify-center font-bold text-white shadow-lg border-2 border-white/20">
              {adminName.charAt(0)}
            </div>
            <div className="overflow-hidden">
              <p className="text-sm font-bold text-white truncate">{adminName}</p>
              <p className="text-[10px] text-[#FF922B] flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
                متصل • بصمة مؤكدة
              </p>
            </div>
          </div>
        </div>
      </aside>

      {/* منطقة العرض الرئيسية (Main Content Area) */}
      <main className="flex-1 overflow-y-auto bg-slate-50/50 p-8">
        <header className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-3xl font-black text-[#1a3a1a] tracking-tighter">
              {menuItems.find(i => i.id === activeTab)?.label}
            </h2>
            <p className="text-sm text-gray-400 font-bold mt-1">
              {new Date().toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>
          
          <div className="flex gap-4 items-center">
            <div className="hidden md:flex flex-col items-end text-[10px] font-black uppercase tracking-widest text-gray-400">
              <span>Sovereign Hub v62.0</span>
              <span className="text-emerald-500">Security: Active</span>
            </div>
            <button className="bg-white p-3 rounded-2xl shadow-sm text-[#1a3a1a] hover:text-[#FF922B] transition-all hover:shadow-md relative group">
              <span className="absolute top-2 right-2 w-3 h-3 bg-red-500 rounded-full border-2 border-white animate-ping"></span>
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
            </button>
          </div>
        </header>

        {/* عرض المكون المناسب بناءً على التبويب المختار */}
        <div className="animate-fade-in">
          {activeTab === 'overview' && <DashboardStats />}
          {activeTab === 'fleet' && <FleetRadar />}
          {activeTab === 'orders' && <OrderManagement />}
          {activeTab === 'products' && <ProductManagement />}
          {activeTab === 'marketing' && <MarketingManagement />}
          {activeTab === 'quality' && <QualityManagement />}
          {activeTab === 'complaints' && <ComplaintsManagement />}
          {activeTab === 'accounting' && <AccountingManagement />}
          {activeTab === 'developer' && <DeveloperManagement />}
        </div>
      </main>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.05);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.2);
        }
      `}</style>
    </div>
  );
}
