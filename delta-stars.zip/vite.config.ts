import path from 'path';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

// Custom plugin to strip React Refresh calls from transformed code
const stripRefreshPlugin = {
  name: 'strip-refresh',
  enforce: 'post' as const,
    transform(code: string, id: string) {
      if (/\.[mc]?[tj]sx?$/.test(id)) {
        // Remove imports of the refresh runtime
        let newCode = code.replace(/import\s+.*?\s+from\s+["']\/@(react-refresh|vite-plugin-react\/refresh-runtime)["'];?/g, '');
        newCode = newCode.replace(/import\s+["']\/@(react-refresh|vite-plugin-react\/refresh-runtime)["'];?/g, '');
        
        // Replace function calls with no-ops that don't break syntax
        // We use a self-executing function that returns an identity function for Sig, and noop for Reg/Register
        newCode = newCode.replace(/RefreshRuntime\.register\(.*?\);?/g, '/* stripped */');
        newCode = newCode.replace(/\$RefreshReg\$\(.*?\);?/g, '/* stripped */');
        newCode = newCode.replace(/\$RefreshSig\$\(.*?\);?/g, '(()=>(t)=>t).call('); // This one often wraps a call, so we keep the call structure
        
        return {
          code: newCode,
          map: null
        };
      }
    }
};

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, '.', '');
    return {
      server: {
        port: 3000,
        host: '0.0.0.0',
        hmr: false,
        watch: {
          usePolling: true,
        }
      },
      plugins: [
        react({ 
          // @ts-expect-error - fastRefresh is not in the type definition but is a valid option
          fastRefresh: false,
          babel: {
            plugins: []
          }
        }),
        tailwindcss(),
        stripRefreshPlugin
      ],
      define: {
        'process.env.API_KEY': JSON.stringify(env.GEMINI_API_KEY),
        'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY),
        '__VITE_PLUGIN_REACT_PREAMBLE_INSTALLED__': 'true',
        // Use global window references for React Refresh identifiers
        'RefreshRuntime': 'window.RefreshRuntime',
        '$RefreshReg$': 'window.$RefreshReg$',
        '$RefreshSig$': 'window.$RefreshSig$',
      },
      resolve: {
        alias: {
          '@': path.resolve(__dirname, '.'),
        },
        dedupe: ['react', 'react-dom'],
      }
    };
});
