import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './components/App';
import { setupMockApi } from './components/lib/mockApi';

// Initialize Mock API Layer
setupMockApi();

/**
 * Delta Stars Sovereign Update Engine v62.0
 * نظام التحديث التلقائي اللحظي والتعافي من الانقطاع
 */
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then(registrations => {
    for (const registration of registrations) {
      registration.unregister();
    }
  });
}

const rootElement = document.getElementById('root');
if (!rootElement) throw new Error("Critical Mount Failure.");

const root = createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
