
import express from 'express';
import fs from 'fs';
import cors from 'cors';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // Intercept ALL possible Vite React Refresh module paths
  app.get(['/@react-refresh*', '/@vite-plugin-react/refresh-runtime*', '/vendor/react-refresh*'], (req, res) => {
    res.set({
      'Content-Type': 'application/javascript',
      'Cache-Control': 'no-store'
    });
    res.send(`
      const noop = () => {};
      const identity = (t) => t;
      const createMock = () => {
        const m = new Proxy(noop, {
          get: (t, p) => {
            if (p === 'createSignatureFunctionForTransform') return () => () => identity;
            if (p === 'register') return noop;
            return m;
          },
          apply: () => m,
          set: () => true
        });
        return m;
      };
      const mock = createMock();
      if (typeof window !== 'undefined') {
        window.RefreshRuntime = mock;
        window.$RefreshReg$ = noop;
        window.$RefreshSig$ = () => identity;
      }
      export default mock;
      export const register = noop;
      export const createSignatureFunctionForTransform = () => () => identity;
      export const performReactRefresh = noop;
      export const injectIntoGlobalHook = noop;
    `);
  });

  // Mock Database (Cloud-ready structure)
  let db = {
    products: [],
    orders: [],
    users: [],
    settings: {
        maintenance: false,
        version: '62.0'
    }
  };

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', version: db.settings.version });
  });

  app.get('/api/products', (req, res) => {
    res.json(db.products);
  });

  app.post('/api/orders', (req, res) => {
    const order = { ...req.body, id: `ORD-${Date.now()}`, timestamp: new Date().toISOString() };
    db.orders.push(order);
    res.status(201).json(order);
  });

  app.get('/api/orders', (req, res) => {
    res.json(db.orders);
  });

  // Vite Middleware for Development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
      configFile: path.resolve(__dirname, 'vite.config.ts'),
    });

    // Handle HTML transformation and stripping BEFORE other middlewares
    app.use(async (req, res, next) => {
      if (req.method === 'GET' && (req.url === '/' || req.url.endsWith('.html') || (!req.url.includes('.') && req.accepts('html')))) {
        try {
          let template = fs.readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
          template = await vite.transformIndexHtml(req.url, template);
          
          // Aggressively strip any injected React Refresh preamble while sparing our safe mock
          // We look for any script containing preamble markers or pointing to @react-refresh that ARE NOT our mock
          template = template.replace(/<script[^>]*>[\s\S]*?(@react-refresh|refresh-runtime|__vite_plugin_react_preamble_installed__|RefreshRuntime)[\s\S]*?<\/script>/gi, (match) => {
            if (match.includes('vite-refresh-mock')) return match; // Keep our mock
            return '';
          });
          template = template.replace(/<script[^>]*src=["']\/@(react-refresh|vite-plugin-react\/refresh-runtime)["'][^>]*><\/script>/gi, '');
          template = template.replace(/<script[^>]*>[\s\S]*?import\s+["']\/@(react-refresh|vite-plugin-react\/refresh-runtime)["'][\s\S]*?<\/script>/gi, '');
          
          // Also strip from module imports in transformed code
          template = template.replace(/import\s+["']\/@(react-refresh|vite-plugin-react\/refresh-runtime)["'];?/g, '');
          
          // Ensure our mock is at the very top of the head
          const mockScriptMatch = template.match(/<script id="vite-refresh-mock">[\s\S]*?<\/script>/);
          if (mockScriptMatch) {
            template = template.replace(mockScriptMatch[0], '');
            template = template.replace(/<head[^>]*>/i, (match) => match + '\n    ' + mockScriptMatch[0]);
          }
          
          return res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
        } catch (e) {
          vite.ssrFixStacktrace(e as Error);
          return next(e);
        }
      }
      next();
    });

    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Delta Sovereign Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
