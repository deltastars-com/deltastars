import React, { useState } from 'react';
import { Product } from '../../types';
import { SparklesIcon, XIcon, QualityIcon, GlobeAltIcon, ChartBarIcon, DocumentTextIcon } from './contexts/Icons';
import { useI18n } from './contexts/I18nContext';

interface ArViewerModalProps {
  product: Product;
  onClose: () => void;
}

/**
 * Delta Stars Sovereign Quality Lab v60.0
 * واجهة غامرة لفحص جودة الأصول الرقمية (Immersive Digital Twin Experience)
 */
export const ArViewerModal: React.FC<ArViewerModalProps> = ({ product, onClose }) => {
  const { language } = useI18n();
  const [isModelLoading, setIsModelLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'visual' | 'diagnostic' | 'origin'>('visual');

  const ModelViewer = 'model-viewer' as any;

  return (
    <div className="fixed inset-0 z-[3000] bg-[#01040a] flex flex-col animate-fade-in overflow-hidden font-cairo selection:bg-secondary/30">
        {/* Deep Atmospheric Lighting */}
        <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-[-20%] left-[-10%] w-[120%] h-[120%] bg-[radial-gradient(circle_at_center,_var(--tw-gradient-from)_0%,_transparent_70%)] from-primary/30 blur-[150px] rounded-full"></div>
            <div className="absolute bottom-[-10%] right-[-10%] w-[100%] h-[100%] bg-[radial-gradient(circle_at_center,_var(--tw-gradient-from)_0%,_transparent_70%)] from-secondary/15 blur-[150px] rounded-full animate-pulse-slow"></div>
            <div className="absolute inset-0 opacity-[0.08] mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
        </div>

        {/* Immersive Diagnostic Header */}
        <header className="relative p-6 md:px-16 md:py-12 flex justify-between items-center z-[3100] backdrop-blur-5xl border-b border-white/10 bg-black/40 shadow-2xl">
            <div className="flex items-center gap-8 md:gap-14">
                <div className="w-16 h-16 md:w-24 md:h-24 bg-gradient-to-br from-primary to-primary-dark rounded-[3rem] flex items-center justify-center shadow-sovereign border-2 border-secondary/30 relative group">
                    <SparklesIcon className="w-8 h-8 md:w-12 md:h-12 text-secondary animate-pulse" />
                    <div className="absolute -inset-3 bg-secondary/10 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
                <div className="space-y-2">
                    <h3 className="text-white font-black text-2xl md:text-6xl uppercase tracking-tighter leading-none mb-1">
                        {language === 'ar' ? 'مختبر فحص الجودة' : 'Quality Inspection Lab'}
                    </h3>
                    <div className="flex items-center gap-6">
                        <div className="flex items-center gap-3">
                             <span className="w-3 h-3 bg-green-500 rounded-full animate-ping"></span>
                             <span className="text-green-500 font-black text-[10px] md:text-sm uppercase tracking-[0.4em]">Secure Link v6.0</span>
                        </div>
                        <span className="text-white/30 text-[10px] md:text-sm font-black uppercase tracking-[0.6em] hidden sm:block">
                            {language === 'ar' ? product.name_ar : product.name_en} • 0x{product.id}D-TWIN
                        </span>
                    </div>
                </div>
            </div>
            
            <button 
                onClick={onClose} 
                className="group p-6 md:p-10 bg-white/5 hover:bg-red-600 text-white rounded-full transition-all border border-white/10 hover:scale-110 active:scale-95 shadow-2xl backdrop-blur-3xl"
                aria-label={language === 'ar' ? 'إغلاق' : 'Close'}
            >
                <XIcon className="w-8 h-8 md:w-12 md:h-12 group-hover:rotate-90 transition-transform duration-700" />
            </button>
        </header>

        {/* Main Workspace Area */}
        <div className="flex-1 relative flex flex-col lg:flex-row overflow-hidden">
            
            {/* 3D Immersive Viewport */}
            <div className="flex-1 relative flex flex-col items-center justify-center p-6 bg-black/30">
                
                {/* Intro Interaction Guidance */}
                {!isModelLoading && (
                    <div className="absolute top-12 left-1/2 -translate-x-1/2 z-40 w-full max-w-2xl px-8 pointer-events-none">
                        <div className="bg-primary/85 backdrop-blur-4xl p-8 rounded-[3.5rem] border border-secondary/30 shadow-sovereign animate-fade-in-up text-center relative overflow-hidden">
                            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-secondary/50 to-transparent"></div>
                            <h4 className="text-secondary font-black text-lg mb-2 uppercase tracking-widest flex items-center justify-center gap-4">
                                <SparklesIcon className="w-6 h-6 animate-spin-slow" />
                                {language === 'ar' ? 'نموذج فحص تفاعلي' : 'Interactive Diagnostic Twin'}
                            </h4>
                            <p className="text-white font-bold text-lg md:text-xl leading-relaxed opacity-95">
                                {language === 'ar' 
                                    ? 'تدوير بإصبع واحد، تكبير بإصبعين. اضغط على الزر البرتقالي بالأسفل لتجربة الثمرة في واقعك الحقيقي.'
                                    : 'Rotate with 1 finger, zoom with 2. Tap the button below to view in your physical space.'}
                            </p>
                        </div>
                    </div>
                )}

                {isModelLoading && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center z-[3050] bg-[#01040a]/98 backdrop-blur-6xl">
                        <div className="relative mb-14">
                             <div className="w-32 h-32 md:w-64 md:h-64 border-[16px] border-white/5 border-t-secondary rounded-full animate-spin"></div>
                             <div className="absolute inset-0 flex items-center justify-center">
                                 <span className="text-white font-black text-3xl animate-pulse tracking-[0.5em] uppercase">DELTA</span>
                             </div>
                        </div>
                        <p className="text-secondary font-black text-sm uppercase tracking-[1.2em] animate-pulse">Initializing Neural Link...</p>
                    </div>
                )}

                <div className="w-full h-full cursor-grab active:cursor-grabbing relative group">
                    {/* Visual Scan Effect Overlay */}
                    {!isModelLoading && <div className="scan-pulse-line"></div>}
                    
                    <ModelViewer
                        src="https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Avocado/glTF-Binary/Avocado.glb"
                        ar
                        ar-modes="webxr scene-viewer quick-look"
                        camera-controls
                        poster={product.image}
                        shadow-intensity="2.5"
                        exposure="1.4"
                        environment-image="neutral"
                        auto-rotate
                        interaction-prompt="auto"
                        onLoad={() => setIsModelLoading(false)}
                        className="w-full h-full"
                    >
                        {/* Sovereign AR Launch Button - Ultra Prominent Styling */}
                        <button slot="ar-button" className="ar-button">
                             {language === 'ar' ? 'فحص في الواقع المعزز (AR)' : 'VIEW IN AUGMENTED REALITY'}
                        </button>
                    </ModelViewer>

                    {/* HUD Telemetry HUD */}
                    <div className="absolute bottom-14 left-14 p-10 bg-black/60 backdrop-blur-5xl rounded-[3.5rem] border border-white/10 text-white/40 font-black text-[10px] uppercase tracking-[0.5em] pointer-events-none hidden xl:flex flex-col gap-6">
                        <div className="flex items-center gap-4"><span className="w-2.5 h-2.5 bg-secondary rounded-full animate-pulse"></span> Rendering Active</div>
                        <div className="w-full h-px bg-white/10"></div>
                        <div className="flex items-center gap-4"><span className="w-2.5 h-2.5 bg-green-500 rounded-full"></span> Tracking 1:1 Scale</div>
                    </div>
                </div>
            </div>

            {/* Diagnostic Data Sidebar */}
            <div className="w-full lg:w-[550px] bg-slate-900/90 backdrop-blur-6xl border-l border-white/10 p-12 md:p-16 flex flex-col gap-12 overflow-y-auto custom-scrollbar">
                
                {/* Modern Context Switcher */}
                <div className="flex bg-black/40 p-2.5 rounded-[2.5rem] border border-white/10 shrink-0 shadow-inner">
                    {['visual', 'diagnostic', 'origin'].map((t) => (
                        <button 
                            key={t}
                            onClick={() => setActiveTab(t as any)}
                            className={`flex-1 py-5 rounded-[2rem] text-[11px] font-black uppercase tracking-widest transition-all duration-500 ${activeTab === t ? 'bg-primary text-secondary shadow-2xl ring-2 ring-secondary/30' : 'text-white/20 hover:text-white/40'}`}
                        >
                            {t === 'visual' ? (language === 'ar' ? 'المظهر' : 'Visual') : (t === 'diagnostic' ? (language === 'ar' ? 'التشخيص' : 'Diagnostic') : (language === 'ar' ? 'المنشأ' : 'Origin'))}
                        </button>
                    ))}
                </div>

                <div className="flex-1 space-y-14">
                    {activeTab === 'visual' && (
                        <div className="space-y-12 animate-fade-in-right">
                            <div className="space-y-8">
                                <h4 className="text-secondary font-black text-xs uppercase tracking-[0.5em] flex items-center gap-5">
                                    <ChartBarIcon className="w-7 h-7" /> 
                                    Asset Narrative
                                </h4>
                                <p className="text-white text-4xl md:text-5xl font-black leading-[1.1] tracking-tighter">
                                    {language === 'ar' ? product.description_ar : product.description_en}
                                </p>
                                <div className="grid grid-cols-2 gap-6">
                                    <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/5 group hover:bg-white/10 transition-all shadow-xl">
                                        <p className="text-white/20 text-[10px] uppercase tracking-widest mb-3">Integrity Tier</p>
                                        <p className="text-white font-black text-2xl tracking-tighter">PREMIUM AAA</p>
                                    </div>
                                    <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/5 group hover:bg-white/10 transition-all shadow-xl">
                                        <p className="text-white/20 text-[10px] uppercase tracking-widest mb-3">Data Protocol</p>
                                        <p className="text-green-500 font-black text-2xl flex items-center gap-3">
                                            LIVE <span className="w-3 h-3 bg-green-500 rounded-full animate-pulse shadow-[0_0_15px_rgba(34,197,94,0.6)]"></span>
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div className="bg-gradient-to-br from-primary to-primary-dark p-12 rounded-[5rem] shadow-sovereign border-b-[18px] border-secondary relative overflow-hidden group">
                                <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 blur-3xl rounded-full group-hover:scale-150 transition-all duration-1000"></div>
                                <QualityIcon className="w-16 h-16 text-secondary mb-8 group-hover:rotate-12 transition-transform" />
                                <h4 className="text-white font-black text-3xl mb-4">التزام الجودة السيادي</h4>
                                <p className="text-white/60 text-lg font-bold leading-relaxed">
                                    {language === 'ar' 
                                        ? 'يتم توريد هذا الصنف وفقاً لأعلى معايير السلامة الغذائية العالمية. النموذج الرقمي هو نسخة مطابقة للمنتج الفعلي بنسبة 100%.' 
                                        : 'This item is supplied under the highest global food safety protocols. The digital twin is a 100% exact replica of the actual product.'}
                                </p>
                            </div>
                        </div>
                    )}

                    {activeTab === 'diagnostic' && (
                        <div className="space-y-12 animate-fade-in-up">
                             <h4 className="text-secondary font-black text-xs uppercase tracking-[0.5em]">Neural Analysis Results</h4>
                             <div className="space-y-10">
                                {[
                                    { label: language === 'ar' ? 'سلامة الأنسجة' : 'Tissue Integrity', val: 98 },
                                    { label: language === 'ar' ? 'تطابق التدرج اللوني' : 'Color Spectrum Sync', val: 99 },
                                    { label: language === 'ar' ? 'الامتثال للوزن النوعي' : 'Specific Weight Compliance', val: 100 },
                                    { label: language === 'ar' ? 'دقة الهوية البصرية' : 'Visual ID Precision', val: 97 }
                                ].map((stat, i) => (
                                    <div key={i} className="space-y-4">
                                        <div className="flex justify-between text-xs font-black uppercase tracking-widest">
                                            <span className="text-white/30">{stat.label}</span>
                                            <span className="text-secondary">{stat.val}%</span>
                                        </div>
                                        <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden border border-white/5 shadow-inner">
                                            <div className="h-full bg-secondary shadow-[0_0_20px_rgba(255,146,43,0.5)] transition-all duration-1000" style={{ width: `${stat.val}%` }}></div>
                                        </div>
                                    </div>
                                ))}
                             </div>
                             <div className="p-8 bg-white/5 rounded-[3rem] border border-white/10 text-center text-white/20 text-sm font-bold italic">
                                Real-time diagnostic processing via Sovereign Node v60.0
                             </div>
                        </div>
                    )}

                    {activeTab === 'origin' && (
                        <div className="space-y-12 animate-fade-in-up">
                            <div className="bg-white/5 p-10 rounded-[3.5rem] border border-white/10 flex items-center gap-10 group hover:bg-white/10 transition-colors">
                                <div className="w-24 h-24 bg-primary/30 rounded-full flex items-center justify-center border-4 border-primary/20 shadow-2xl">
                                    <GlobeAltIcon className="w-12 h-12 text-secondary group-hover:scale-110 transition-transform" />
                                </div>
                                <div>
                                    <h5 className="text-white/20 font-black text-[11px] uppercase tracking-[0.5em] mb-2">Verified Source Authentication</h5>
                                    <p className="text-white font-black text-3xl uppercase tracking-tighter">
                                        {language === 'ar' ? product.origin_ar : product.origin_en}
                                    </p>
                                </div>
                            </div>
                            <div className="p-10 bg-blue-600/10 rounded-[4rem] border-2 border-blue-500/20 text-blue-400 relative overflow-hidden shadow-2xl">
                                <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 blur-3xl rounded-full"></div>
                                <p className="text-lg font-bold leading-relaxed relative z-10">
                                    {language === 'ar' 
                                        ? 'تم توثيق بيانات التوريد عبر بلوكشين "الأقمشة" لضمان أعلى مستويات الشفافية والموثوقية في كل طلبية.'
                                        : 'Supply data documented via Al-Aqmesha blockchain to ensure the highest levels of transparency and reliability in every order.'}
                                </p>
                            </div>
                        </div>
                    )}
                </div>

                {/* Lab Control Actions */}
                <div className="pt-12 border-t border-white/10 mt-auto shrink-0">
                    <button 
                        onClick={onClose}
                        className="w-full py-10 bg-white text-primary rounded-[3.5rem] font-black text-3xl hover:bg-secondary hover:text-white transition-all shadow-sovereign hover:scale-[1.03] active:scale-95 flex items-center justify-center gap-8 border-b-[12px] border-gray-200 hover:border-orange-900"
                    >
                        {language === 'ar' ? 'إنهاء الفحص الرقمي' : 'TERMINATE INSPECTION'}
                    </button>
                    <div className="mt-10 text-center">
                        <p className="text-[10px] font-black text-white/10 uppercase tracking-[0.8em]">Sovereign Diagnostic Center • Node v60.0 Secure</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};